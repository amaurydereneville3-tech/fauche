// Test des nouveautés V7 côté serveur
const { io } = require('socket.io-client');
const URL = process.env.URL || 'http://localhost:3995';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const errs = [];
async function login(pseudo) {
  let r = await fetch(URL + '/api/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ pseudo, pass: 'secret123', age: true }) });
  if (r.status === 409) r = await fetch(URL + '/api/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ pseudo, pass: 'secret123' }) });
  const { token } = await r.json(); const s = io(URL, { auth: { token } }); const st = { me: null, ev: {}, last: {} };
  s.onAny((e, d) => { st.ev[e] = (st.ev[e] || 0) + 1; st.last[e] = d; if (e === 'me') st.me = d; });
  const api = async (n, p, quiet) => { await sleep(30); return new Promise(res => s.emit('api', n, p || {}, x => { if (!x.ok && !quiet) errs.push(pseudo + ' ' + n + ': ' + x.err); res(x.ok ? x.r || {} : { err: x.err }); })); };
  await new Promise(r => s.on('me', r)); return { s, st, api };
}
(async () => {
  const t = Date.now() % 1000, A = await login('V7A' + t), B = await login('V7B' + t), M = await login('monorime');
  for (const P of [A, B]) { await P.api('tutoDone'); await M.api('admLevel', { id: P.st.me.id, xp: 60000 }); await M.api('admGive', { id: P.st.me.id, amt: 30000000 }); }
  await sleep(300); console.log('cash', A.st.me.cash, 'hello jp7', JSON.stringify(A.st.last.hello && A.st.last.hello.jp7), 'saison', JSON.stringify(A.st.last.hello && A.st.last.hello.season));
  // lingots
  let r = await A.api('lgStart', { amt: 1000 }); let t0 = r.t0; console.log('lgStart', JSON.stringify(r));
  for (let k = 0; k < 4 && r && !r.lose && !r.done; k++) { await sleep(300); r = await A.api('lgTap', { ms: Date.now() - t0 + (A.st.me.now - Date.now()) }); console.log(' tap', JSON.stringify(r).slice(0, 100)); if (r.t0) t0 = r.t0; }
  if (r && !r.lose && !r.done) console.log(' out', JSON.stringify(await A.api('lgOut', {}, true)));
  // machines
  r = await A.api('bfSpin', { amt: 100 }); console.log('bonbons', r.total, 'tours', r.spins && r.spins.length, 'étapes', r.spins && r.spins[0].steps.length);
  r = await A.api('bfSpin', { amt: 100, buy: 1 }); console.log('bonbons bonus acheté', r.total, 'tours gratuits', r.fs, 'mise', r.stake);
  r = await A.api('pmSpin', { amt: 100 }); console.log('pêche', r.total, 'lignes', JSON.stringify(r.spins[0].lines));
  // coffre-fort
  await A.api('cfJoin'); r = await A.api('cfGuess', { k: 'b', g: '01234' }); console.log('coffre', JSON.stringify(r)); r = await A.api('cfGuess', { k: 'b', g: '56789' }, true); console.log('coffre trop vite', JSON.stringify(r));
  r = await B.api('cfGuess', { k: 'b', g: '11234' }, true); console.log('coffre code invalide', JSON.stringify(r));
  // luxe
  console.log('bouteille', JSON.stringify(await A.api('bottle', { id: 'b3' })));
  console.log('flTop', JSON.stringify(await A.api('flTop')).slice(0, 120));
  console.log('voiture', JSON.stringify(await A.api('luxBuy', { id: 'c_lambo' })), 'montre', JSON.stringify(await A.api('luxBuy', { id: 'w_rolax' })));
  await sleep(200); console.log('fortune', A.st.me.worth, 'cash', A.st.me.cash);
  console.log('course', JSON.stringify(await A.api('streetRace', { i: 2, amt: 1000 })));
  console.log('vente', JSON.stringify(await A.api('luxSell', { id: 'w_rolax' })));
  console.log('humilier', JSON.stringify(await A.api('humiliate', { id: B.st.me.id, nick: 'Le Pigeon' })));
  console.log('profil B', JSON.stringify((await A.api('profile', { id: B.st.me.id })).nick));
  console.log('enlever', JSON.stringify(await B.api('unhumiliate')));
  // placements
  const dc = await A.api('dcJoin'); console.log('dc', dc.p, dc.h.length); console.log('dcBuy', JSON.stringify(await A.api('dcBuy', { amt: 10000 }))); console.log('dcSell', JSON.stringify(await A.api('dcSell', { part: 1 })));
  console.log('nft', JSON.stringify(await A.api('nftBuy', { amt: 5000 })), 'startup', JSON.stringify(await A.api('stBuy', { amt: 5000 })), 'livret', JSON.stringify(await A.api('lvDeposit', { amt: 5000 })));
  console.log('invInfo', JSON.stringify(await A.api('invInfo')).slice(0, 160));
  // saison, passe, boss, prestige
  console.log('seaTop', JSON.stringify(await A.api('seaTop')).slice(0, 200));
  console.log('pass7', JSON.stringify(await A.api('pass7Claim', { i: 1 }, true)));
  console.log('boss', JSON.stringify(await A.api('bossTop')).slice(0, 200));
  console.log('coffre du jour', JSON.stringify(await A.api('chest', {}, true)));
  await M.api('admGive', { id: B.st.me.id, amt: 20000000 }); await sleep(200); console.log('prestige', JSON.stringify(await B.api('prestige'))); await sleep(200); console.log('B après', B.st.me.cash, B.st.me.prestige);
  // crash : encaisser avec le moment du clic
  await A.api('crashJoin'); let w = 0; while (A.st.last.crash && A.st.last.crash.phase !== 'bet' && w++ < 100) await sleep(200);
  await A.api('crashBet', { amt: 100 }); w = 0; while ((!A.st.last.crash || A.st.last.crash.phase !== 'fly') && w++ < 100) await sleep(100);
  await sleep(300); const cr = A.st.last.crash; r = await A.api('crashOut', { ms: Date.now() + (A.st.me.now - Date.now()) - cr.start }, true); console.log('crashOut', JSON.stringify(r));
  console.log('ERREURS', errs); process.exit(0);
})();
