// Banc d'essai : charge le serveur en mémoire (sans réseau) et mesure le taux de retour des jeux.
process.env.DATA_FILE = process.env.DATA_FILE || require('path').join(require('os').tmpdir(), 'rtp-' + process.pid + '.json');
const C = require('../server/core');
C.api = {}; C.hello = []; C.leave = [];
const fakeRoom = { emit() {}, to() { return fakeRoom; }, in() { return fakeRoom; } };
C.io = { emit() {}, to() { return fakeRoom; }, in() { return fakeRoom; }, sockets: { sockets: new Map(), adapter: { rooms: new Map() } } };
['live', 'poker', 'blackjack', 'solo', 'sport', 'business', 'shop', 'social', 'casino2', 'extras', 'account', 'v6games', 'v6social', 'push', 'v7games', 'v7', 'v7lux'].forEach(m => { try { require('../server/games/' + m); } catch (e) { console.error('module', m, e.message); } });
const ST = {}; const orig = C.result;
const FAST = process.env.FULL ? 0 : 1;
C.result = (u, g, s, p, x) => { const k = u.tag || g; const r = ST[k] = ST[k] || { n: 0, s: 0, p: 0, big: 0 }; r.n++; r.s += s; r.p += p; if (p > s * 50) r.big++; if (!FAST) return orig(u, g, s, p, x); };
if (FAST) { C.money = (u, d) => { u.d.cash = Math.max(0, Math.round(u.d.cash + d)); }; C.checkAch = () => {}; C.feed = () => {}; C.sysChat = () => {}; C.notify = () => {}; C.track = () => {}; C.xp = () => {}; }
let uid = 900000;
function mk(tag) { const u = { id: uid++, pseudo: 'T' + uid, d: C.freshData(), sockets: new Set(), dirty: false, s: {}, tag }; u.d.cash = 1e15; u.d.xp = 1e9; u.d.tutoDone = true; C.users.set(u.id, u); return u; }
function rep(tag) { const r = ST[tag]; if (!r) return tag + ': rien'; return tag.padEnd(28) + ' parties ' + String(r.n).padStart(7) + '  retour ' + (r.p / r.s * 100).toFixed(1).padStart(6) + ' %'; }
const sleep = ms => new Promise(r => setTimeout(r, ms));
function call(u, n, p) { return C.api[n](u, p || {}); }
function tryCall(u, n, p) { try { return C.api[n](u, p || {}); } catch (e) { return { err: e.message }; } }
module.exports = { C, D: C.D, mk, rep, ST, sleep, call, tryCall };
