/* Fauché V7 : données partagées (serveur + navigateur) */
(function (D) {
  D.VERSION = '7.0';

  /* ---------- Récompenses proportionnelles à la fortune ----------
     Une récompense « de base » est pensée pour un joueur à 2 M€. Au-dessus, elle grandit avec la fortune. */
  D.REF = 2e6;
  D.nice = n => { n = Math.round(n); if (n < 1000) return Math.round(n / 10) * 10; const p = Math.pow(10, Math.floor(Math.log10(n)) - 1); return Math.round(n / p) * p; };
  D.scaleCash = (worth, base) => D.nice(Math.max(base, (worth || 0) * base / D.REF));
  D.boostPrice = (b, worth) => Math.max(b.pr, D.nice((worth || 0) * .003));

  /* ---------- VIP (selon tout ce que tu as misé depuis le début) ---------- */
  D.VIP = [
    { k: 'bronze', nm: 'Bronze', min: 0, cb: 0, chest: 1, col: '#c48a5c' },
    { k: 'argent', nm: 'Argent', min: 1e5, cb: .005, chest: 1.25, col: '#c8d0dc' },
    { k: 'or', nm: 'Or', min: 5e6, cb: .01, chest: 1.5, col: '#f2c14e' },
    { k: 'platine', nm: 'Platine', min: 2.5e8, cb: .015, chest: 2, col: '#8fd8ff' },
    { k: 'diamant', nm: 'Diamant', min: 1e10, cb: .025, chest: 3, col: '#b9f2ff' }];
  D.vipOf = wag => { let i = 0; D.VIP.forEach((v, k) => { if ((wag || 0) >= v.min) i = k; }); return i; };

  /* ---------- Jackpots progressifs (tombent au hasard sur n'importe quel jeu du casino) ---------- */
  D.JP7 = [{ k: 'mini', nm: 'Mini', seed: 2500, share: .003, col: '#39d98a' }, { k: 'maj', nm: 'Majeur', seed: 100000, share: .0015, col: '#4cc9f0' }, { k: 'mega', nm: 'Méga', seed: 5e6, share: .0007, col: '#f2c14e' }];
  D.JP_EXCL = ['job', 'arc', 'auction', 'bourse', 'heist', 'crate', 'tourney', 'cf', 'lux', 'invest', 'mo', 'duel'];

  /* ---------- Saisons de 30 jours ---------- */
  D.SEASON_EPOCH = '2026-10-15'; D.SEASON_DAYS = 30;
  D.seasonOf = date => { const t0 = Date.parse(D.SEASON_EPOCH + 'T00:00:00Z'), t = Date.parse(date + 'T00:00:00Z'); const n = Math.max(0, Math.floor((t - t0) / 864e5 / D.SEASON_DAYS)) + 1;
    const s = new Date(t0 + (n - 1) * D.SEASON_DAYS * 864e5), e = new Date(s.getTime() + (D.SEASON_DAYS - 1) * 864e5); return { n, start: s.toISOString().slice(0, 10), end: e.toISOString().slice(0, 10) }; };
  D.SEA_PRIZES = [50000, 25000, 10000]; // de base, multipliés selon la fortune
  D.PASS7_XP = 1200; D.PASS7_N = 50;
  D.pass7 = i => { // i = palier 1..50
    if (i === 50) return { t: 'title', v: 'Légende de la saison', nm: 'Titre « Légende de la saison »' };
    if (i === 40) return { t: 'nc', v: 'fire', nm: 'Pseudo en feu' };
    if (i === 25) return { t: 'nc', v: 'gold', nm: 'Pseudo doré' };
    if (i === 15) return { t: 'nc', v: 'ice', nm: 'Pseudo glacé' };
    if (i % 10 === 0) return { t: 'crate', v: 'o', nm: 'Caisse Or' };
    if (i % 5 === 0) return { t: 'crate', v: i > 25 ? 'a' : 'b', nm: i > 25 ? 'Caisse Argent' : 'Caisse Bronze' };
    if (i % 7 === 0) return { t: 'boost', v: ['parrain', 'requin', 'flambeur'][i % 3], nm: '3 boosts' };
    return { t: 'cash', v: 1500 + i * 400, nm: 'Argent' }; };
  D.NCOL = { gold: { nm: 'Doré', css: 'nc-gold' }, ice: { nm: 'Glacé', css: 'nc-ice' }, fire: { nm: 'En feu', css: 'nc-fire' }, rainbow: { nm: 'Arc-en-ciel', css: 'nc-rainbow' } };

  /* ---------- Prestige ---------- */
  D.prestigeNeed = p => 1e7 * Math.pow(10, p || 0);

  /* ---------- Événements ---------- */
  D.EV7 = [{ k: 'halloween', nm: 'Halloween', from: '2026-10-24', to: '2026-11-02', col: '#ff7a1a' }];
  D.eventOn = date => D.EV7.find(e => date >= e.from && date <= e.to) || null;
  D.isWeekend = date => { const d = new Date(date + 'T12:00:00Z').getUTCDay(); return d === 0 || d === 6; };
  D.PUMPKIN_SHOP = [{ n: 10, t: 'crate', v: 'b', nm: 'Caisse Bronze' }, { n: 25, t: 'crate', v: 'a', nm: 'Caisse Argent' }, { n: 60, t: 'title', v: 'Roi d\'Halloween', nm: 'Titre « Roi d\'Halloween »' }, { n: 100, t: 'nc', v: 'rainbow', nm: 'Pseudo arc-en-ciel' }];

  /* ---------- Boss de la semaine ---------- */
  D.BOSS7 = { nm: 'Gérard l\'huissier', hp: 3000, base: 30000, min: 10, full: 150 };
  D.bossDmg = stake => 1 + Math.min(4, Math.floor(Math.log10(Math.max(1, stake)) / 2));

  /* ---------- Défis du Croupier (une seule tentative, mise minimum) ---------- */
  D.CHAL7 = [{ g: 'crash', m: 5, p: .192 }, { g: 'limbo', m: 10, p: .096 }, { g: 'tower', m: 6, p: .178 }, { g: 'chicken', m: 10, p: .434 }, { g: 'mines', m: 3, p: .32 }, { g: 'pen', m: 4, p: .41 }, { g: 'dice', m: 10, p: .096 }, { g: 'ballon', m: 3, p: .32 }];

  /* ---------- Le Carré VIP ---------- */
  D.BOTTLES = [
    { id: 'b1', nm: 'Bouteille du Carré', pr: 2500, d: 'Le minimum pour pas passer pour un radin' },
    { id: 'b2', nm: 'Magnum + cierges', pr: 25000, d: 'Annonce dans le chat' },
    { id: 'b3', nm: 'Jéroboam', pr: 250000, d: 'Le DJ crie ton pseudo' },
    { id: 'b4', nm: 'Le Mur de bouteilles', pr: 5e6, d: 'Ton avatar sur l\'écran géant pendant 1 h' },
    { id: 'b5', nm: 'Nabuchodonosor en or', pr: 1e9, d: 'Titre « Le Sultan » pour toujours', title: 'Le Sultan' },
    { id: 'b6', nm: 'Privatiser la boîte', pr: 1e11, d: '1 % de la somme pleut sur les joueurs connectés', rain: .01 }];
  D.DJ = ['Grosse dédicace à {p} qui vient de commander {b} ! Et pendant ce temps {k} boit de l\'eau du robinet.',
    '{p} commande {b}. Le videur l\'appelle « patron » maintenant.', 'Tout le monde lève son verre pour {p} et son {b} ! Sauf {k}, qui fait semblant d\'aller aux toilettes.',
    '{p} vient de claquer {b}. Sa banque a appelé pour vérifier que tout allait bien.', 'Le DJ coupe la musique : {p} a commandé {b}. {k}, regarde et apprends.'];

  /* ---------- Garage et montres (noms parodiés) ---------- */
  D.CARS7 = [
    { id: 'c_clia', nm: 'Rénault Clia', pr: 8000, sp: 5, col: '#e5e0d8', sh: 0 }, { id: 'c_golfe', nm: 'Golfe GTI', pr: 35000, sp: 7, col: '#4cc9f0', sh: 0 },
    { id: 'c_merco', nm: 'Mercédès AMJ', pr: 180000, sp: 9, col: '#c8d0dc', sh: 1 }, { id: 'c_porche', nm: 'Porche 912', pr: 450000, sp: 10, col: '#ff4d5e', sh: 1 },
    { id: 'c_lambo', nm: 'Lambordini', pr: 2e6, sp: 12, col: '#f2c14e', sh: 2 }, { id: 'c_ferra', nm: 'Ferrori', pr: 8e6, sp: 13, col: '#e0262f', sh: 2 },
    { id: 'c_buga', nm: 'Bugatto', pr: 5e7, sp: 15, col: '#2d6cdf', sh: 2 }, { id: 'c_fusee', nm: 'Fusée privée', pr: 2e9, sp: 20, col: '#f6efe4', sh: 3 }];
  D.WATCH7 = [
    { id: 'w_casiot', nm: 'Casiot', pr: 50, k: 'digital', col: '#3a3a3a' }, { id: 'w_swotch', nm: 'Swotch', pr: 150, k: 'plastic', col: '#ff5fb2' },
    { id: 'w_seika', nm: 'Seika', pr: 900, k: 'steel', col: '#1f3b6b' }, { id: 'w_tagg', nm: 'Tag Hoyer', pr: 4000, k: 'steel', col: '#111' },
    { id: 'w_rolax', nm: 'Rolax', pr: 15000, k: 'gold', col: '#14351f' }, { id: 'w_audy', nm: 'Audemars Pigné', pr: 120000, k: 'steel', col: '#1d2a5a' },
    { id: 'w_patek', nm: 'Patek Philou', pr: 2e6, k: 'gold', col: '#f6efe4' }, { id: 'w_tourb', nm: 'Tourbillon en diamant', pr: 5e8, k: 'dia', col: '#0d0d14' }];
  D.luxInfo = id => D.CARS7.find(x => x.id === id) || D.WATCH7.find(x => x.id === id) || null;
  D.luxValue = (g, now) => { const it = D.luxInfo(g.id); if (!it) return 0; const days = Math.max(0, ((now || Date.now()) - g.at) / 864e5); const car = it.id[0] === 'c';
    return Math.round(g.pr * .9 * Math.max(car ? .4 : .6, Math.pow(car ? .98 : .995, days))); };

  /* ---------- Humiliation ---------- */
  D.NICKS = ['Le Radin du Morbihan', 'Le Pigeon', 'Monsieur Zéro Euro', 'Le Rat des Tables', 'Pleure-au-Crash', 'Le Fauché Officiel', 'Le Roi du Découvert', 'Kevin 2.0',
    'Le Stagiaire du Casino', 'Mains Moites', 'Le Sponsor du Casino', 'Champion du Rien', 'Le Mendiant de Luxe', 'Allergique au Gain', 'La Banque du Casino', 'Doigts de Beurre',
    'Le Touriste', 'Tête de Ticket Perdant', 'Le Bébé Joueur', 'Ruiné Volontaire'];
  D.humPrice = worth => Math.max(20000, D.nice((worth || 0) * .005));

  /* ---------- Placements foireux ---------- */
  D.INV = {
    dc: { nm: 'DaronCoin', fee: .01 },
    nft: { nm: 'NFT de Kevin', h: 1, out: [[0, .58], [1.2, .25], [2.5, .13], [5, .036], [20, .004]], arts: ['Singe qui pleure', 'Pigeon en costard', 'Kebab doré', 'Chat qui juge', 'Grand-mère cyborg', 'Licorne fauchée'] },
    st: { nm: 'Start-up de Kevin', h: 3, out: [[0, .72], [2, .19], [4, .075], [12, .015]], ideas: ['Uber pour chiens', 'Tinder pour plantes', 'Kebab en abonnement', 'Airbnb pour places de parking', 'Réseau social pour daron', 'Livraison de cailloux'] },
    lv: { nm: 'Livret Mamie', rate: .003, days: 7 } };

  /* ---------- Nouveaux jeux ---------- */
  // Bonbons Fous : grille 6 × 5, gains à partir de 8 bonbons identiques n'importe où, cascades, bombes multiplicatrices en tours gratuits
  D.BF = { cols: 6, rows: 5, sym: [
    { k: 'heart', w: 4, p: [10, 25, 50], col: '#ff3b5c' }, { k: 'star', w: 5, p: [2.5, 10, 25], col: '#a35cf0' }, { k: 'gem', w: 6, p: [2, 5, 15], col: '#39d98a' },
    { k: 'drop', w: 7, p: [1.5, 2, 12], col: '#4cc9f0' }, { k: 'sq', w: 8, p: [1, 1.5, 10], col: '#ffb02e' }, { k: 'ring', w: 9, p: [.8, 1.2, 8], col: '#ff8ad0' },
    { k: 'bean', w: 10, p: [.5, 1, 5], col: '#5fd39a' }, { k: 'mint', w: 11, p: [.25, .75, 2], col: '#e3fcff' }],
    sc: { k: 'lolly', w: 1.1 }, bomb: { k: 'bomb', w: 2.6, v: [2, 2, 2, 3, 3, 4, 5, 5, 6, 8, 10, 12, 15, 20, 25, 50, 100] }, fs: 10, scPay: { 4: 3, 5: 5, 6: 100 }, buy: 115, adj: 1.02 };
  // Pêche Miraculeuse : 5 × 3, 10 lignes, poissons à valeur, le pêcheur ramasse tout en tours gratuits
  D.PM = { lines: [[1, 1, 1, 1, 1], [0, 0, 0, 0, 0], [2, 2, 2, 2, 2], [0, 1, 2, 1, 0], [2, 1, 0, 1, 2], [0, 0, 1, 2, 2], [2, 2, 1, 0, 0], [1, 0, 0, 0, 1], [1, 2, 2, 2, 1], [1, 0, 1, 2, 1]],
    sym: [{ k: 'boat', w: 2, p: [34, 160, 800] }, { k: 'rod', w: 3, p: [20, 80, 340] }, { k: 'box', w: 4, p: [14, 40, 160] }, { k: 'bob', w: 5, p: [8, 27, 110] }, { k: 'Q', w: 7, p: [5, 14, 55] }, { k: 'J', w: 7, p: [5, 14, 55] }],
    fish: { k: 'fish', w: 2, v: [.1, .1, .2, .2, .25, .25, .5, .5, 1, 1, 2, 5, 10] }, wild: { k: 'man', w: 1 }, sc: { k: 'hook', w: .7 }, fs: 10, fsWild: .95, adj: .99 };
  // Coffre-fort en direct : code à 5 chiffres différents, le premier qui trouve rafle la cagnotte
  D.CF = [{ k: 'b', nm: 'Coffre Bronze', fee: 1000, col: '#c48a5c' }, { k: 'o', nm: 'Coffre Or', fee: 50000, col: '#f2c14e' }, { k: 'd', nm: 'Coffre Diamant', fee: 2e6, col: '#8fd8ff' }];
  D.CF_LEN = 5; D.CF_CUT = .05; D.CF_CD = 5000;
  D.cfScore = (code, g) => { let b = 0, m = 0; for (let i = 0; i < code.length; i++) { if (g[i] === code[i]) b++; else if (code.includes(g[i])) m++; } return { b, m }; };
  // Tour de lingots V7 : 12 étages, combo « Parfait », étages piégés, coffre au sommet
  D.LG2 = { cols: 15, w0: 3, floors: 12, min: 3, mult: [0, 0, 0, .95, .97, 1, 1.1, 1.25, 1.5, 1.9, 2.6, 4, 7], speed: f => 15 + f * 2 + (f >= 9 ? (f - 8) * 4 : 0), trapK: 1.35, combo: 3 };
  D.lg2Pos = (ms, w, f, ph, inv) => { const L = D.LG2, R = L.cols - w; if (R <= 0) return 0; const sp = L.speed(f) * (inv ? L.trapK : 1); let t = ms / 1000 * sp + ph; const per = 2 * R; t = ((t % per) + per) % per; let x = t < R ? t : per - t; if (inv) x = R - x; return Math.min(R, Math.max(0, Math.round(x))); };

  /* ---------- Noms, niveaux, missions ---------- */
  Object.assign(D.GN, { bonbons: 'aux Bonbons Fous', peche: 'à la Pêche Miraculeuse', cf: 'au Coffre-fort', lingots: 'à la Tour de lingots' });
  Object.assign(D.GLV, { bonbons: 2, peche: 3, cf: 4 });
  D.MISSIONS.push(
    { id: 'bf20', t: 'Fais 20 tours aux Bonbons Fous', type: 'play', g: 'bonbons', n: 20, rw: 900 }, { id: 'bfx', t: 'Gagne ×10 ou plus aux Bonbons Fous', type: 'mult', g: 'bonbons', n: 10, rw: 2500 },
    { id: 'pm20', t: 'Fais 20 tours à la Pêche Miraculeuse', type: 'play', g: 'peche', n: 20, rw: 900 }, { id: 'lg6', t: 'Monte 6 étages à la Tour de lingots', type: 'mult', g: 'lingots', n: 6, rw: 1500 },
    { id: 'cf3', t: 'Tente 3 codes au Coffre-fort', type: 'play', g: 'cf', n: 3, rw: 800 }, { id: 'flb', t: 'Commande une bouteille au Carré VIP', type: 'play', g: 'lux', n: 1, rw: 600 },
    { id: 'win15', t: 'Gagne 15 parties', type: 'win', n: 15, rw: 1500 }, { id: 'play40', t: 'Joue 40 parties', type: 'play', n: 40, rw: 1200 },
    { id: 'bal3', t: 'Encaisse à ×3 ou plus au Ballon', type: 'mult', g: 'ballon', n: 3, rw: 1200 }, { id: 'wshow5', t: 'Mise sur 5 tours de Grande Roue', type: 'play', g: 'wshow', n: 5, rw: 700 });
  D.WMIS.push({ id: 'w_bf', t: 'Fais 150 tours aux Bonbons Fous', type: 'play', g: 'bonbons', n: 150, rw: 20000 }, { id: 'w_lg', t: 'Atteins l\'étage 9 de la Tour de lingots', type: 'mult', g: 'lingots', n: 9, rw: 25000 },
    { id: 'w_cf', t: 'Crack un coffre-fort', type: 'win', g: 'cf', n: 1, rw: 30000 });
  D.ACH.push({ id: 'prestige', ic: '⭐', nm: 'Prestige', d: 'Passer en prestige', f: 0 }, { id: 'sultan', ic: '🍾', nm: 'Le Sultan', d: 'Commander un Nabuchodonosor en or', f: 0 },
    { id: 'jp7', ic: '💰', nm: 'Jackpot !', d: 'Décrocher un jackpot progressif', f: 0 }, { id: 'boss', ic: '🥊', nm: 'Tombeur d\'huissier', d: 'Participer à la chute de Gérard', f: 0 },
    { id: 'cfwin', ic: '🔐', nm: 'Perceur de coffres', d: 'Cracker un coffre-fort en direct', f: 0 }, { id: 'lgtop', ic: '🧱', nm: 'Le coffre au sommet', d: 'Atteindre l\'étage 12 de la Tour de lingots', f: 0 },
    { id: 'humi', ic: '🤡', nm: 'Humilié', d: 'Se faire imposer un surnom', f: 0, sh: 1 }, { id: 'dcrug', ic: '📉', nm: 'Rug pull', d: 'Perdre 90 % sur le DaronCoin', f: 0, sh: 1 });
})(typeof module !== 'undefined' ? (module.exports = require('./data6')) : window.D);
