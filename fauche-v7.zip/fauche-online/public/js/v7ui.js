/* ====================== V7 : accueil, VIP, jackpots, saison, prestige, luxe ====================== */
function ncCls(nc){return nc&&D.NCOL[nc]?D.NCOL[nc].css:''}
const rwOf=b=>Math.round(D.scaleCash(S.worth,b)*(1+(S.prestige||0)*.05));
let JP7=null,BOSS7=null,EV7=null,WEEKEND=false,SEASON7=null,WALL7=null,MISLOAD=0;
on('hello',h=>{if(h.jp7)JP7=h.jp7;if(h.boss)BOSS7=h.boss;EV7=h.ev7||null;WEEKEND=!!h.weekend;SEASON7=h.season||SEASON7;WALL7=h.wall||null;jpTick()});
on('jp7',j=>{JP7=j;jpTick()});
on('jpWin',w=>{if(w.pseudo===S.pseudo){burst(90);snd('big');shake()}else snd('notif');notif('💰','Jackpot '+w.nm,w.pseudo+' rafle '+eur(w.amt)+' !',()=>go('home'))});
on('boss',b=>{BOSS7=Object.assign(BOSS7||{},b);$$('[data-bosshp]').forEach(e=>e.style.width=Math.max(0,b.hp/b.max*100)+'%');$$('[data-bosstx]').forEach(e=>e.textContent=b.dead?'K.O. !':fr.format(b.hp)+' PV')});
on('wall',w=>{WALL7=w;if(tab==='home'&&!modalOpen())render()});
on('pumpkin',p=>{S.pumpkin=p.n;toast('🎃 Citrouille trouvée ! Tu en as '+p.n+'.');snd('coin')});
function jpTick(){if(!JP7)return;$$('[data-jp]').forEach(e=>{e.textContent=e.dataset.short?short2(JP7[e.dataset.jp]):eur(JP7[e.dataset.jp])})}
setInterval(()=>{if(JP7&&tab==='home')jpTick()},5000);
const vipNow=()=>{const i=D.vipOf(S.wag||0),V=D.VIP[i],N=D.VIP[i+1];return{i,V,N,pct:N?Math.min(100,((S.wag||0)-V.min)/(N.min-V.min)*100):100}};
const VIPSVG=c=>`<svg width="42" height="42" viewBox="0 0 46 46" aria-hidden="true"><path d="M23 3l18 14-18 26L5 17z" fill="${c}"/><path d="M5 17h36M14 17l9 26 9-26M14 17l9-14 9 14" fill="none" stroke="#fff" opacity=".45" stroke-width="1.2"/></svg>`;
const nickOn=()=>S.nick&&S.nick.until>now();
const sea=()=>S.sea&&SEASON7&&S.sea.n===SEASON7.n?S.sea:{n:SEASON7?SEASON7.n:1,pts:0,claimed:[]};
const passT7=()=>Math.min(D.PASS7_N,Math.floor(sea().pts/D.PASS7_XP));

/* ---------- Accueil V7 ---------- */
VIEWS.home=v=>{const L=D.levelOf(S.xp),d=parisDate(),day=S.day&&S.day.date===d?S.day:{net:0,games:0,best:0},Cc=S.challenge,cact=Cc&&!Cc.done&&now()<Cc.until;
  const h=new Date().getHours(),hi=h<5?'Encore debout':h<12?'Bonjour':h<18?'Salut':'Bonsoir',hp=(S.happyUntil||0)>now(),jail=(S.jailUntil||0)>now(),vp=vipNow();
  const mis=S.mis&&S.mis.date===d?S.mis.list:null;if(!mis&&MISLOAD<2){MISLOAD++;api('missions').then(()=>setTimeout(()=>{if(tab==='home')render()},300)).catch(()=>{})}
  const t7=passT7(),open7=Array.from({length:t7},(_,i)=>i+1).filter(i=>!sea().claimed.includes(i)).length,B=BOSS7;
  const card=(act,ic,b,n,hot)=>`<button class="hcard ${hot?'hot':''}" ${act}><span class="i">${ic}</span><b>${b}</b><span class="note">${n}</span></button>`;
  v.innerHTML=`<div class="hello6"><button class="avbtn" data-act="go" data-t="moi" data-s="avatar" aria-label="Mon avatar">${avHTML(60)}</button><div style="min-width:0"><h2 style="margin:0">${hi} <span class="${ncCls(S.nc)}">${esc(me())}</span>${S.prestige?` <span class="prb">⭐${S.prestige}</span>`:''}</h2><span class="note">Niveau ${L.l} · ${esc(title())}</span></div></div>
  ${nickOn()?`<div class="nickban"><span class="k">SURNOM IMPOSÉ PAR ${esc(S.nick.by).toUpperCase()} · ENCORE ${Math.ceil((S.nick.until-now())/3600000)} H</span><b>« ${esc(S.nick.t)} »</b><button class="btn sm" data-act="unhum">Payer ${eur(S.nick.paid*2)} pour l'effacer</button></div>`:''}
  ${hp?`<button class="happy6" data-act="tab" data-v="casino"><b>🍾 HAPPY HOUR</b><span>XP ×2 et pluie de drops · encore ${Math.ceil((S.happyUntil-now())/60000)} min</span></button>`:''}
  ${jail?`<button class="happy6 jail" data-act="tab" data-v="casino"><b>🚔 EN PRISON</b><span>Encore <span data-secs="${S.jailUntil}">${secs(S.jailUntil)}</span> s · corromps le gardien ou évade-toi</span></button>`:''}
  ${EV7&&EV7.k==='halloween'?`<button class="happy6 hallo" data-act="go" data-t="social" data-s="saison"><b>🎃 HALLOWEEN</b><span>Des citrouilles tombent dans tous les jeux · tu en as ${S.pumpkin||0} · boutique dans Social › Saison</span></button>`:''}
  ${WEEKEND?`<div class="wkend">🎉 C'est le week-end : <b>XP ×1,5</b> sur tout</div>`:''}
  ${WALL7&&WALL7.until>now()?`<div class="wall7"><span class="note">SUR L'ÉCRAN GÉANT DU CARRÉ VIP</span><div>${fc({av:WALL7.av},54)}<b>${esc(WALL7.pseudo)}</b><span class="note">a commandé le Mur de bouteilles</span></div></div>`:''}
  <button class="vip7" data-act="vipinfo" style="--vc:${vp.V.col}">${VIPSVG(vp.V.col)}<span class="vt"><span class="vh"><b>VIP ${vp.V.nm}</b><span class="note">${vp.N?vp.N.nm+' à '+Math.floor(vp.pct)+' %':'Niveau max'}</span></span><span class="progress"><i style="width:${vp.pct}%"></i></span><span class="note">${vp.V.cb?'Cashback '+String(vp.V.cb*100).replace('.',',')+' % chaque lundi · ':''}coffre du jour ×${String(vp.V.chest).replace('.',',')}</span></span></button>
  <section class="jp7"><div class="k">JACKPOTS PROGRESSIFS</div><b class="num big" data-jp="mega">${JP7?eur(JP7.mega):'…'}</b><div class="note">Méga · peut tomber sur n'importe quelle mise du casino</div>
    <div class="jp3">${D.JP7.map(j=>`<div style="--jc:${j.col}"><span>${j.nm.toUpperCase()}</span><b class="num" data-jp="${j.k}" data-short="1">${JP7?short2(JP7[j.k]):'…'}</b></div>`).join('')}</div></section>
  <div class="daycard"><div><span class="note">Aujourd'hui</span><b class="num ${day.net>0?'upc':day.net<0?'dnc':''}">${day.net>=0?'+':''}${eur(day.net)}</b></div><div><span class="note">Parties</span><b class="num">${day.games}</b></div><div><span class="note">Meilleur coup</span><b class="num">${eur(Math.max(0,day.best))}</b></div></div>
  <section class="mis7"><div class="mh"><h3>Missions du jour</h3><button class="linkbtn" data-act="go" data-t="moi" data-s="missions">Semaine ›</button></div>
    ${mis?mis.map(m=>{const M=D.MISSIONS.find(x=>x.id===m.id);if(!M)return'';const done=m.p>=M.n;return`<div class="mi ${m.c?'ok':''}"><div class="mt2"><span>${esc(M.t)}</span>${m.c?'<b class="okc">✓</b>':done?`<button class="btn gold sm" data-act="mclaim" data-v="${m.id}">+${eur(rwOf(M.rw))}</button>`:`<b class="rw">+${eur(rwOf(M.rw))}</b>`}</div><div class="progress"><i style="width:${Math.min(100,m.p/M.n*100)}%"></i></div></div>`}).join(''):'<div class="note">Chargement…</div>'}
    <div class="strk"><span class="note">Série de connexion : ${(S.streak&&S.streak.n)||0} jour${(S.streak&&S.streak.n)>1?'s':''}. Chaque jour d'affilée, le coffre rapporte plus.</span><span class="pips">${Array.from({length:7},(_,i)=>`<i class="${i<((S.streak&&S.streak.n)||0)%8?'on':''} ${i===6?'gold':''}"></i>`).join('')}</span></div></section>
  <div class="hgrid">
    ${giftReady()?card('data-act="gift"','🎁','Cadeaux du jour','Coffre + roue gratuite'+(S.streak&&S.streak.n?' · série '+S.streak.n+' 🔥':''),1):''}
    ${cact?card(`data-act="go" data-t="casino" data-s="${Cc.game}"`,'🤝','Défi du Croupier',esc(Cc.txt)+' · mise mini '+eur(Cc.min||0)+' · gain '+eur(Cc.amt),1):''}
    ${B?`<button class="hcard boss7 ${B.dead?'':'hot'}" data-act="go" data-t="social" data-s="saison"><span class="i">🥊</span><b>${B.dead?'Gérard est K.O. !':'Boss : Gérard l\'huissier'}</b><span class="bbar"><i data-bosshp style="width:${Math.max(0,B.hp/B.max*100)}%"></i></span><span class="note"><span data-bosstx>${B.dead?'K.O. !':fr.format(B.hp)+' PV'}</span> · chaque mise le frappe</span></button>`:''}
    ${card('data-act="go" data-t="social" data-s="saison"','🏆','Saison '+sea().n,'Fin le '+(SEASON7?new Date(SEASON7.end+'T12:00:00').toLocaleDateString('fr-FR',{day:'numeric',month:'long'}):'…')+' · '+fr.format(sea().pts)+' pts')}
    ${card('data-act="go" data-t="moi" data-s="pass"','⭐','Passe · palier '+t7+'/'+D.PASS7_N,open7?open7+' récompense'+(open7>1?'s':'')+' à prendre !':'Joue pour monter',open7)}
    ${card('data-act="go" data-t="social" data-s="week"','👑','Classement de la semaine','Les prix suivent ta fortune')}
    ${S.pending>=1?card('data-act="go" data-t="marches" data-s="biz"','🏪',eur(S.pending),'à encaisser de tes entreprises'):''}
    ${unread?card('data-act="go" data-t="social" data-s="chat"','💬',unread+' message'+(unread>1?'s':''),'dans le chat du casino'):''}
  </div>
  <h3 class="h6">Nouveautés V7</h3><div class="lobby6">${['lingots','bonbons','peche','cf'].map(id=>GAMES.find(g=>g.id===id)).filter(Boolean).map(x=>`<button class="gtile" style="--tc:${x.c}" data-act="go" data-t="casino" data-s="${x.id}">${x.lv&&LV()<x.lv?`<span class="lockb">🔒 Niv. ${x.lv}</span>`:`<span class="new">${x.id==='lingots'?'REFAIT':'NOUVEAU'}</span>`}<span class="art">${gameArt(x)}</span><span class="gtx"><b>${x.nm}</b></span></button>`).join('')}
    ${[['carre','Le Carré VIP','#a35cf0',LUXART.carre],['garage','Garage & montres','#e3b558',LUXART.garage],['invest','Placements foireux','#39d98a',LUXART.invest]].map(([s2,nm,c,a])=>`<button class="gtile" style="--tc:${c}" data-act="go" data-t="vie" data-s="${s2}"><span class="new">NOUVEAU</span><span class="art">${a}</span><span class="gtx"><b>${nm}</b></span></button>`).join('')}</div>
  <h3 class="h6">En ce moment</h3><div class="feed7">${FEED.slice(0,5).map(f=>`<div>${f}</div>`).join('')||'<div class="note">Calme plat. Lance une partie !</div>'}</div>
  ${CREDIT}`};
ACT.vipinfo=()=>{const vp=vipNow();modal(`<p class="mt">💎 Statut VIP</p><p class="note">Ton statut monte avec tout ce que tu mises au casino depuis le début (${eur(S.wag||0)}).</p>
  <div class="viplist">${D.VIP.map((V,i)=>`<div class="${i===vp.i?'on':''}" style="--vc:${V.col}">${VIPSVG(V.col)}<span><b>${V.nm}</b><br><span class="note">dès ${eur(V.min)} misés</span></span><span class="note">${V.cb?'Cashback '+String(V.cb*100).replace('.',',')+' %':'—'}<br>coffre ×${String(V.chest).replace('.',',')}</span></div>`).join('')}</div>
  <p class="note">Le cashback est versé chaque lundi : un pourcentage de ce que tu as perdu dans la semaine.</p><button class="btn" data-close>Fermer</button>`)};
ACT.unhum=()=>{modal(`<p class="mt">🧽 Effacer ton surnom ?</p><p>Ça coûte <b>${eur(S.nick.paid*2)}</b> (le double de ce que ${esc(S.nick.by)} a payé). Sinon, il part tout seul dans ${Math.ceil((S.nick.until-now())/3600000)} h.</p><div class="row2"><button class="btn" data-close>Je garde</button><button class="btn gold" data-act="unhumok">Payer</button></div>`)};
ACT.unhumok=async()=>{try{await api('unhumiliate');closeModal();toast('Surnom effacé. Ça pique, hein ?');render()}catch(e){}};

/* ---------- Social : saison, boss, Halloween ---------- */
{const _vs=VIEWS.social;VIEWS.social=v=>{if(sub.social!=='saison')return _vs(v);const n=(S.loanReq||[]).length;
  v.innerHTML=`<h2>Social</h2><p class="sub">${ONLINE.length} joueur${ONLINE.length>1?'s':''} en ligne.</p>${segHTML('social',[['chat','Chat'],['players','En ligne'],['saison','Saison'],['week','Semaine'],['top','Fortune'],['loans','Prêts'+(n?' ('+n+')':'')]])}<div class="section" style="margin-top:12px" id="sov"></div>`;rSaison($('#sov'))}}
{const _seg=segHTML;segHTML=function(k,opts){if(k==='social'&&!opts.some(o=>o[0]==='saison'))opts=[opts[0],opts[1],['saison','Saison'],...opts.slice(2)];return _seg(k,opts)}}
async function rSaison(v){v.innerHTML='<div class="empty">Chargement…</div>';let r,b;try{[r,b]=await Promise.all([api('seaTop'),api('bossTop')])}catch(e){return}if(sub.social!=='saison'||!$('#sov'))return;BOSS7=Object.assign(BOSS7||{},b);
  const end=new Date(r.end+'T23:59:00'),left=Math.max(0,Math.ceil((end-Date.now())/864e5));
  v.innerHTML=`<section class="boss7big ${b.dead?'dead':''}"><div class="bh"><span class="bart">${GERARD}</span><span><b>Gérard l'huissier</b><br><span class="note">Boss de la semaine · ${b.n} joueur${b.n>1?'s':''} sur lui</span></span></div>
    <div class="bbar big"><i data-bosshp style="width:${Math.max(0,b.hp/b.max*100)}%"></i><span data-bosstx>${b.dead?'K.O. !':fr.format(b.hp)+' / '+fr.format(b.max)+' PV'}</span></div>
    <p class="note">${b.dead?'Il est tombé ! Le butin a été partagé. Il revient lundi, plus énervé.':`Chaque mise au casino lui met un coup (plus la mise est grosse, plus ça frappe, jusqu'à 5). Quand il tombe, chaque joueur qui a frappé au moins ${D.BOSS7.min} fois touche jusqu'à <b>${eur(b.reward)}</b>.`} Tes coups : <b>${b.mine}</b>.</p>
    ${b.rows.length?`<div class="brows">${b.rows.slice(0,5).map((x,i)=>`<span>${i+1}. ${esc(x.pseudo)} · ${x.d}</span>`).join('')}</div>`:''}</section>
  ${EV7&&EV7.k==='halloween'?`<section class="hallo7"><b>🎃 Boutique d'Halloween</b><span class="note">Tu as <b>${S.pumpkin||0}</b> citrouille${(S.pumpkin||0)>1?'s':''}. Elles tombent au hasard quand tu joues, jusqu'au ${new Date(EV7.to+'T12:00:00').toLocaleDateString('fr-FR',{day:'numeric',month:'long'})}.</span>
    ${D.PUMPKIN_SHOP.map((it,i)=>`<div class="lrow2"><span>${it.nm}</span><button class="btn sm ${(S.pumpkin||0)>=it.n?'gold':''}" data-act="pumpbuy" data-v="${i}" ${(S.pumpkin||0)>=it.n?'':'disabled'}>🎃 ${it.n}</button></div>`).join('')}</section>`:''}
  <div class="weekhead"><span><b>Saison ${r.n}</b><br><span class="note">Points de saison = l'XP gagnée depuis le ${new Date(r.start+'T12:00:00').toLocaleDateString('fr-FR',{day:'numeric',month:'long'})}. Encore ${left} jour${left>1?'s':''}. ${r.me?'Tu es '+r.me+(r.me>1?'e':'er')+'.':''}</span></span><span class="prz">${r.prizes.map((p,i)=>`<span>${['🥇','🥈','🥉'][i]} ${short2(p)} €</span>`).join('')}</span></div>
  ${r.rows.map((p,i)=>`<button class="prow ${p.id===S.id?'mine':''}" data-act="prof" data-v="${p.id}"><span>${i<3?['🥇','🥈','🥉'][i]:(i+1)+'.'} ${fc(p,30)} <b>${esc(p.pseudo)}</b></span><span class="num">${fr.format(p.pts)} pts</span></button>`).join('')||'<div class="empty">Personne n\'a encore de points. Fonce !</div>'}
  <p class="note">À la fin de la saison : un trophée pour le podium, de l'argent selon ta fortune, et le titre « Champion de la saison » pour le 1er. Puis tout le monde repart à zéro.</p>`}
ACT.pumpbuy=async el=>{try{const r=await api('pumpkinBuy',{i:+el.dataset.v});toast('🎃 '+r.txt+' !');burst(20);render()}catch(e){}};
const GERARD=`<svg viewBox="0 0 60 60" width="52" height="52" aria-hidden="true"><circle cx="30" cy="30" r="28" fill="#3a2a2a"/><circle cx="30" cy="26" r="12" fill="#e8b98f"/><path d="M18 22c2-10 22-10 24 0" fill="#7a7a7a"/><rect x="20" y="22" width="9" height="5" rx="2" fill="none" stroke="#111" stroke-width="1.6"/><rect x="31" y="22" width="9" height="5" rx="2" fill="none" stroke="#111" stroke-width="1.6"/><path d="M25 33c3-2 7-2 10 0" stroke="#5c1a1a" stroke-width="2" fill="none"/><path d="M12 58c2-12 9-18 18-18s16 6 18 18z" fill="#1d2a44"/><path d="M27 40l3 10 3-10" fill="#c3203a"/><rect x="38" y="44" width="14" height="10" rx="1" fill="#7a4f0c"/></svg>`;

/* ---------- Moi : passe de saison, prestige, couleur du pseudo ---------- */
function rPass7(v){const s=sea(),t=passT7(),cur=s.pts%D.PASS7_XP,need=D.prestigeNeed(S.prestige||0),can=S.worth>=need;
  v.innerHTML=`<section class="pass7h"><b>Passe de la saison ${s.n}</b><span class="note">Palier ${t}/${D.PASS7_N} · ${fr.format(s.pts)} points · ${fr.format(D.PASS7_XP-cur)} avant le prochain</span><div class="progress"><i style="width:${t>=D.PASS7_N?100:cur/D.PASS7_XP*100}%"></i></div></section>
  <div class="pass7">${Array.from({length:D.PASS7_N},(_,k)=>{const i=k+1,R=D.pass7(i),got=s.claimed.includes(i),ok=i<=t;const lab=R.t==='cash'?eur(rwOf(R.v)):R.nm;
    return`<button class="pt7 ${got?'got':ok?'ok':''} ${i%10===0||i===25||i===15?'big':''}" data-act="${ok&&!got?'p7claim':'noop'}" data-v="${i}" ${ok&&!got?'':'aria-disabled="true"'}><span class="n">${i}</span><span class="ic">${{cash:'💵',crate:'📦',boost:'⚡',title:'🏅',nc:'🎨'}[R.t]}</span><span class="l">${esc(lab)}</span>${got?'<span class="ck">✓</span>':''}</button>`}).join('')}</div>
  <section class="nc7"><b>Couleur de ton pseudo</b><span class="note">Se débloque avec le passe et les événements. Visible dans le chat.</span><div class="ncs"><button class="btn sm ${!S.nc?'gold':''}" data-act="ncset" data-v="">Normal</button>${(S.ncs||[]).map(k=>`<button class="btn sm ${S.nc===k?'gold':''}" data-act="ncset" data-v="${k}"><span class="${ncCls(k)}">${D.NCOL[k].nm}</span></button>`).join('')}</div></section>
  <section class="prest7"><div><b>⭐ Prestige ${S.prestige||0}</b><span class="note">Tu remets ton argent, tes biens, ton garage et tes placements à zéro. En échange : +10 % d'XP pour toujours (cumulable), +5 % sur les missions, un badge ⭐ et un titre. Tu gardes ton niveau, ton avatar, tes succès et tes amis.</span></div>
    <div class="progress"><i style="width:${Math.min(100,S.worth/need*100)}%"></i></div><span class="note">Il faut ${eur(need)} de patrimoine (tu as ${eur(S.worth)}).</span>
    <button class="btn ${can?'gold':''}" data-act="prestige" ${can?'':'disabled'}>Passer en prestige ${(S.prestige||0)+1}</button></section>`}
{const _vm=VIEWS.moi;VIEWS.moi=v=>{_vm(v);if(sub.moi==='pass'){const s=$('.seg button[data-v="pass"]');if(s)s.textContent='Passe';rPass7($('#mvv'))}else{const s=$('.seg button[data-v="pass"]');if(s)s.textContent='Passe'}}}
ACT.noop=()=>{};
ACT.p7claim=async el=>{try{const r=await api('pass7Claim',{i:+el.dataset.v});toast('🎁 '+r.txt);burst(16);snd('coin');render()}catch(e){}};
ACT.ncset=async el=>{try{await api('setNc',{v:el.dataset.v});render()}catch(e){}};
ACT.prestige=()=>{const p=(S.prestige||0)+1;modal(`<p class="mt">⭐ Prestige ${p}</p><p>Tu vas perdre <b>tout ton argent, tes biens, tes entreprises, ton garage et tes placements</b> (${eur(S.worth)}).</p><p>Tu gagnes : <b>+${p*10} % d'XP pour toujours</b>, +${p*5} % sur les missions, le badge ⭐${p} et le titre « Prestige ${p} ». Tout le chat sera prévenu.</p><p class="note">C'est définitif.</p><div class="row2"><button class="btn" data-close>Non, je garde mes sous</button><button class="btn gold" data-act="prestigeok">Je repars de zéro</button></div>`)};
ACT.prestigeok=async()=>{try{const r=await api('prestige');closeModal();burst(120);snd('level');modal(`<p class="mt">⭐ PRESTIGE ${r.prestige}</p><p>Respect. Tu repars avec 1 000 € et l'honneur.</p><button class="btn gold" data-close>Let's go</button>`)}catch(e){}};

/* ---------- Profils : surnom, badges, garage, humiliation ---------- */
function PROF_V7(p){const V=D.VIP[p.vip||0];return`${p.nick?`<div class="nickban"><span class="k">SURNOM IMPOSÉ PAR ${esc(p.nick.by).toUpperCase()} · ENCORE ${Math.ceil((p.nick.until-now())/3600000)} H</span><b>« ${esc(p.nick.t)} »</b></div>`:''}
  <div class="badges7"><span class="tag" style="border-color:${V.col}">💎 VIP ${V.nm}</span>${p.prestige?`<span class="tag gold">⭐ Prestige ${p.prestige}</span>`:''}${(p.trophies||[]).map(t=>`<span class="tag">${['🏆','🥈','🥉'][t.rank-1]} Saison ${t.n}</span>`).join('')}${p.flambe?`<span class="tag pink">🍾 ${short2(p.flambe)} € flambés</span>`:''}${p.humis?`<span class="tag bad">🤡 Humilié ${p.humis}×</span>`:''}${p.jp7w?`<span class="tag gold">💰 ${p.jp7w} jackpot${p.jp7w>1?'s':''}</span>`:''}</div>
  ${p.gar&&p.gar.length?`<h3 style="margin:6px 0 0">Garage & montres</h3><div class="gar7">${p.gar.map(g=>{const it=D.luxInfo(g.id);return it?`<div>${luxArt(it,56)}<small>${esc(it.nm)}</small><span class="note num">${short2(g.v)} €</span></div>`:''}).join('')}</div>`:''}`}
PROF_EXTRA.push(p=>p.nick?'':`<button class="btn humb" data-act="hum" data-v="${p.id}" data-n="${esc(p.pseudo)}" data-pr="${p.humPrice}">🤡 Humilier · ${eur(p.humPrice)}</button>`);
let HUMSEL='';
ACT.hum=el=>{const id=el.dataset.v,n=el.dataset.n,pr=+el.dataset.pr;HUMSEL=D.NICKS[Math.random()*D.NICKS.length|0];
  modal(`<p class="mt">🤡 Humilier ${esc(n)}</p><p class="note">Pendant 24 h, son surnom s'affiche sur son profil et dans le chat. Il peut l'effacer en payant le double (${eur(pr*2)}).</p>
  <div class="nicks">${D.NICKS.map(x=>`<button class="btn sm ${x===HUMSEL?'gold':''}" data-act="humpick" data-v="${esc(x)}">${esc(x)}</button>`).join('')}</div>
  <label class="sin"><span>Ou invente le tien (24 caractères max)</span><input id="humC" maxlength="24" placeholder="Ex. : Le Roi du Ticket Perdant"></label>
  <div class="row2"><button class="btn" data-close>Annuler</button><button class="btn gold" data-act="humgo" data-v="${id}">Payer ${eur(pr)}</button></div>`)};
ACT.humpick=el=>{HUMSEL=el.dataset.v;$$('.nicks button').forEach(b=>b.classList.toggle('gold',b.dataset.v===HUMSEL));const c=$('#humC');if(c)c.value=''};
ACT.humgo=async el=>{const c=$('#humC'),nick=c&&c.value.trim()?c.value.trim():HUMSEL;try{await api('humiliate',{id:+el.dataset.v,nick});closeModal();toast('C\'est fait. Il va adorer.');snd('big')}catch(e){}};

/* ---------- Ma vie : Carré VIP, garage, placements ---------- */
const LUXART={carre:sv(`<rect width="100" height="80" fill="#22093a"/><path d="M20 0L40 80M60 0L48 80M88 0L70 80" stroke="#ff5fb2" stroke-width="10" opacity=".25"/><g transform="translate(36 6)"><path d="M10 0h8v12c6 4 8 10 8 16v38a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3V28c0-6 2-12 8-16z" fill="#1d3b2a" stroke="#39d98a" stroke-width="1.2"/><rect x="8" y="-4" width="12" height="8" rx="2" fill="url(#gGoldUI)"/><rect x="5" y="34" width="18" height="14" rx="2" fill="url(#gGoldUI)"/></g>`),
  garage:sv(`<rect width="100" height="80" fill="#2a1d05"/><path d="M8 52c0-8 6-11 13-12l15-10c4-3 9-4 15-4h9c7 0 11 2 15 6l9 8c5 1 9 3 9 10v5H8z" fill="#f2c14e"/><path d="M38 31l-9 9h22V28h-5c-3 0-6 1-8 3zM55 28v12h20l-8-7c-3-3-6-5-12-5z" fill="#2a1d33"/><circle cx="26" cy="58" r="8" fill="#1a1006" stroke="#a99bb0" stroke-width="2.5"/><circle cx="76" cy="58" r="8" fill="#1a1006" stroke="#a99bb0" stroke-width="2.5"/>`),
  invest:sv(`<rect width="100" height="80" fill="#0d2a1d"/><path d="M6 60L20 52L30 58L42 30L52 40L62 22L74 50L84 44L94 12" stroke="#39d98a" stroke-width="3.5" fill="none" stroke-linejoin="round"/><path d="M62 22L74 50" stroke="#ff4d5e" stroke-width="3.5"/><circle cx="20" cy="22" r="11" fill="#f2c14e"/><text x="20" y="26.5" text-anchor="middle" font-size="12" font-weight="900" font-family="sans-serif" fill="#3a2508">D</text>`)};
VIE.unshift(['vie','carre','Le Carré VIP','Flambe devant tout le monde','#a35cf0',ico('<path d="M10 2h4v4c2 1 3 3 3 5v10a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1V11c0-2 1-4 3-5z"/><path d="M7 14h10"/>',30)],
  ['vie','garage','Garage & montres','Voitures et montres qui en jettent','#e3b558',ico('<path d="M3 15c0-2 1-3 3-3l3-4h6l3 4c2 0 3 1 3 3v3H3z"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',30)],
  ['vie','invest','Placements foireux','DaronCoin, NFT de Kevin, Livret Mamie','#39d98a',ico('<path d="M3 20h18"/><path d="M4 16l5-6 4 3 7-9"/>',30)]);
{const _vie=VIEWS.vie;VIEWS.vie=v=>{const s=sub.vie;if(!['carre','garage','invest'].includes(s))return _vie(v);
  v.innerHTML=backBar('Ma vie','data-act="sub" data-k="vie" data-v="null"')+`<div class="section" id="mvv"></div>`;({carre:rCarre,garage:rGarage,invest:rInvest})[s]($('#mvv'))}}

let BOTN=1;
async function rCarre(v){const top=await api('flTop').catch(()=>({rows:[],me:0}));if(sub.vie!=='carre'||!$('#mvv'))return;
  v.innerHTML=`<section class="carre7"><div class="k">BOÎTE DE NUIT</div><h2>Le Carré VIP</h2><p>Tu commandes, le DJ crie ton nom, tout le chat le voit. Tu as flambé <b class="num">${eur(S.flambe||0)}</b> au total.</p></section>
  <div class="seg">${[1,5,10].map(n=>`<button data-act="botn" data-v="${n}" class="${BOTN===n?'on':''}">× ${n}</button>`).join('')}</div>
  <div class="bottles">${D.BOTTLES.map((b,i)=>`<div class="bot7 ${b.title?'gold':''} ${b.rain?'pink':''}"><span class="bart">${bottleArt(i)}</span><span class="bt"><b>${b.nm}</b><span class="note">${b.d}</span></span><button class="btn ${b.title?'gold':''}" data-act="bottle" data-v="${b.id}" ${S.cash>=b.pr*BOTN?'':'disabled'}><span class="num">${short2(b.pr*BOTN)} €</span></button></div>`).join('')}</div>
  <h3 class="h6">Flambeurs de la semaine</h3>${top.rows.map((p,i)=>`<button class="prow ${p.id===S.id?'mine':''}" data-act="prof" data-v="${p.id}"><span>${i<3?['🥇','🥈','🥉'][i]:(i+1)+'.'} ${fc(p,28)} <b>${esc(p.pseudo)}</b></span><span class="num pinkc">${eur(p.v)}</span></button>`).join('')||'<div class="empty">Personne n\'a encore flambé cette semaine. Radins.</div>'}`}
ACT.botn=el=>{BOTN=+el.dataset.v;render()};
ACT.bottle=async el=>{const b=D.BOTTLES.find(x=>x.id===el.dataset.v),cost=b.pr*BOTN;const go_=async()=>{try{const r=await api('bottle',{id:b.id,n:BOTN});closeModal();burst(b.pr>=1e6?80:24);snd('big');toast('🍾 '+(BOTN>1?BOTN+' × ':'')+b.nm+' : −'+eur(r.cost));render()}catch(e){}};
  if(cost>=Math.max(100000,S.cash*.2)){modal(`<p class="mt">🍾 Sûr ?</p><p>${BOTN>1?BOTN+' × ':''}${b.nm} pour <b>${eur(cost)}</b>. C'est ${Math.round(cost/Math.max(1,S.cash)*100)} % de ton cash. Tu ne récupères rien, à part la gloire.</p><div class="row2"><button class="btn" data-close>Non</button><button class="btn gold" id="botOk">Flamber</button></div>`);$('#botOk').onclick=go_}else go_()};
function bottleArt(i){const s=[.7,.8,.9,1,1,1][i]||1,g=i===4?'url(#gGoldUI)':'#1d5a3a';return`<svg viewBox="0 0 40 50" width="34" height="44" aria-hidden="true">${i===3?'<g fill="#1d5a3a"><path d="M4 18h5v6c3 2 4 4 4 7v15H0V31c0-3 1-5 4-7z"/><path d="M15 10h6v8c3 2 5 5 5 9v19H10V27c0-4 2-7 5-9z"/><path d="M27 18h5v6c3 2 4 4 4 7v15H23V31c0-3 1-5 4-7z"/></g>':i===5?'<rect x="3" y="18" width="34" height="30" rx="3" fill="#2a1638" stroke="#ff5fb2" stroke-width="1.5"/><path d="M3 18L20 6l17 12" fill="none" stroke="#ff5fb2" stroke-width="1.5"/><rect x="16" y="32" width="8" height="16" fill="#ff5fb2"/>':`<g transform="translate(${20-20*s} ${50-50*s}) scale(${s})"><path d="M15 2h10v9c7 4 9 10 9 16v20a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V27c0-6 2-12 9-16z" fill="${g}" stroke="#39d98a" stroke-width="1"/><rect x="8" y="26" width="24" height="12" rx="2" fill="${i===4?'#7a4f0c':'url(#gGoldUI)'}"/></g>`}</svg>`}

let GART7='cars';
function luxArt(it,w=84){if(it.id[0]==='c'){const c=it.col,sh=it.sh;
    if(sh===3)return`<svg viewBox="0 0 84 40" width="${w}" aria-hidden="true"><path d="M8 20c10-10 40-12 60-6l10 6-10 6c-20 6-50 4-60-6z" fill="${c}"/><path d="M8 20l-6-8v16z" fill="#ff5fb2"/><path d="M2 16l-6 4 6 4" fill="#ffb02e"/><circle cx="54" cy="18" r="4" fill="#4cc9f0"/></svg>`;
    const body=sh===2?'M4 30c0-5 4-7 10-8l16-10c4-2 8-3 14-3h6c6 0 10 2 14 6l8 6c4 1 8 3 8 8v3H4z':sh===1?'M6 30c0-5 3-8 8-9l10-8c3-2 6-3 10-3h14c4 0 7 1 10 4l8 7c5 1 10 3 10 8v3H6z':'M10 30c0-5 3-7 7-8l8-8c3-2 5-3 9-3h12c4 0 6 1 9 4l7 7c5 1 9 3 9 8v3H10z';
    return`<svg viewBox="0 0 84 40" width="${w}" aria-hidden="true"><path d="${body}" fill="${c}"/><path d="M${sh===2?30:28} 13l-${sh===2?8:6} 8h20v-10h-5c-3 0-5 0-7 2zM45 11v10h17l-6-6c-2-2-5-4-11-4z" fill="#2a1d33" opacity=".85"/><circle cx="${sh===0?25:22}" cy="32" r="6" fill="#1a1006" stroke="#a99bb0" stroke-width="2"/><circle cx="${sh===0?60:63}" cy="32" r="6" fill="#1a1006" stroke="#a99bb0" stroke-width="2"/></svg>`}
  const k=it.k,c=it.col,band=k==='gold'?'#9a6512':k==='digital'||k==='plastic'?c:'#8a929e',ring=k==='gold'?'url(#gGoldUI)':k==='dia'?'#e3fcff':k==='digital'?'#3a3a3a':k==='plastic'?c:'#c8d0dc';
  return`<svg viewBox="0 0 40 48" width="${w*.55}" aria-hidden="true"><rect x="13" y="0" width="14" height="48" rx="3" fill="${band}"/>${k==='digital'?`<rect x="6" y="12" width="28" height="24" rx="4" fill="#2a2a2a"/><rect x="9" y="16" width="22" height="13" rx="2" fill="#9fb59a"/><text x="20" y="25.5" text-anchor="middle" font-size="7" font-weight="700" font-family="monospace" fill="#1a2a18">12:00</text>`:`<circle cx="20" cy="24" r="14" fill="${ring}"/><circle cx="20" cy="24" r="10.5" fill="${c}"/>${k==='dia'?'<circle cx="20" cy="24" r="12.5" fill="none" stroke="#fff" stroke-width="1.5" stroke-dasharray="1.5 1.5"/>':''}<path d="M20 24V16.5M20 24l5 3" stroke="${c==='#f6efe4'?'#1a1a1a':'#fff4c9'}" stroke-width="1.8" stroke-linecap="round"/>`}</svg>`}
function rGarage(v){const own=id=>(S.gar||[]).find(g=>g.id===id),list=GART7==='cars'?D.CARS7:D.WATCH7,val=(S.gar||[]).reduce((a,g)=>a+D.luxValue(g),0);
  v.innerHTML=`<h2>Garage & montres</h2><p class="sub">Tout est visible sur ton profil. Les voitures perdent 2 % par jour (les montres beaucoup moins). Valeur actuelle : <b class="num" style="color:var(--gold)">${eur(val)}</b>.</p>
  <div class="seg"><button data-act="gart" data-v="cars" class="${GART7==='cars'?'on':''}">Voitures</button><button data-act="gart" data-v="watch" class="${GART7==='watch'?'on':''}">Montres</button></div>
  <div class="lux7">${list.map(it=>{const g=own(it.id);return`<div class="lx ${g?'own':''}"><span class="la">${luxArt(it)}</span><span class="lt"><b>${esc(it.nm)}</b><span class="note">${g?'Vaut '+eur(D.luxValue(g))+' · acheté '+eur(g.pr):eur(it.pr)+(it.sp?' · vitesse '+it.sp:'')}</span></span>${g?`<button class="btn sm" data-act="luxsell" data-v="${it.id}">Vendre</button>`:`<button class="btn sm gold" data-act="luxbuy" data-v="${it.id}" ${S.cash>=it.pr?'':'disabled'}>Acheter</button>`}</div>`}).join('')}</div>
  <p class="note">Ta meilleure voiture compte pour les courses de rue (Ma vie › Ma ville).</p>`}
ACT.gart=el=>{GART7=el.dataset.v;render()};
ACT.luxbuy=async el=>{const it=D.luxInfo(el.dataset.v);try{await api('luxBuy',{id:it.id});burst(it.pr>=1e6?60:20);snd('big');toast('🔑 '+it.nm+' est à toi !');render()}catch(e){}};
ACT.luxsell=async el=>{try{const r=await api('luxSell',{id:el.dataset.v});toast('Vendu : +'+eur(r.v));render()}catch(e){}};

let INV7=null,DC7=null,INVAMT=1000;
on('dc',d=>{if(DC7){DC7.p=d.p;DC7.h.push(d.p);if(DC7.h.length>180)DC7.h.shift();if(tab==='vie'&&sub.vie==='invest'){const e=$('#dcP');if(e)e.textContent=dcFmt(d.p);dcDraw()}}});
on('dcNews',n=>{if(tab==='vie'&&sub.vie==='invest')notif(n.up?'🚀':'📉','DaronCoin',n.txt);if(DC7)DC7.news=n.txt});
const dcFmt=p=>(p>=1?p.toFixed(2):p>=.01?p.toFixed(4):p.toPrecision(3)).replace('.',',')+' €';
function dcDraw(){const c=$('#dcC');if(!c||!DC7||DC7.h.length<2)return;const h=DC7.h,W=c.width=c.clientWidth*2,H=c.height=260,g=c.getContext('2d'),lo=Math.min(...h),hi=Math.max(...h),y=p=>H-10-(Math.log(p)-Math.log(lo))/(Math.log(hi)-Math.log(lo)||1)*(H-20);
  g.clearRect(0,0,W,H);const up=h[h.length-1]>=h[0];g.strokeStyle=up?'#39d98a':'#ff4d5e';g.lineWidth=4;g.beginPath();h.forEach((p,i)=>{const x=i/(h.length-1)*W;i?g.lineTo(x,y(p)):g.moveTo(x,y(p))});g.stroke();g.lineTo(W,H);g.lineTo(0,H);g.closePath();g.fillStyle=up?'rgba(57,217,138,.12)':'rgba(255,77,94,.12)';g.fill()}
async function rInvest(v){if(!DC7){try{DC7=await api('dcJoin');onLeave(()=>{DC7=null;quiet(api('dcLeave'))})}catch(e){return}}let r;try{r=await api('invInfo')}catch(e){return}if(sub.vie!=='invest'||!$('#mvv'))return;INV7=r.inv;
  const iv=r.inv,dcV=iv.dc*DC7.p,pnl=dcV-iv.dcCost,tl=x=>{const m=Math.max(0,x.end-now());return m>864e5?Math.ceil(m/864e5)+' j':m>36e5?Math.ceil(m/36e5)+' h':Math.ceil(m/6e4)+' min'};
  v.innerHTML=`<h2>Placements foireux</h2><p class="sub">Ici, tu peux tout perdre… ou faire ×10. Montant : </p>
  <div class="seg amt7">${[1000,10000,100000,1e6,1e7,1e8,1e9].filter(a=>a<=Math.max(1000,S.cash)).map(a=>`<button data-act="invamt" data-v="${a}" class="${INVAMT===a?'on':''}">${short2(a)}</button>`).join('')}<button data-act="invamt" data-v="${Math.floor(S.cash)}" class="${INVAMT===Math.floor(S.cash)?'on':''}">Tapis</button></div>
  <section class="dc7"><div class="dch">${coinD()}<span><b>DaronCoin</b><br><span class="note">Lancé par le Daron « sur les conseils d'un mec au PMU »</span></span></div>
    <div class="dcp"><b class="num" id="dcP">${dcFmt(DC7.p)}</b>${DC7.news?`<span class="note">${esc(DC7.news)}</span>`:''}</div><canvas id="dcC" class="dccv" aria-label="Cours du DaronCoin"></canvas>
    <div class="tags"><span class="tag bad">RISQUE : EXTRÊME</span><span class="tag">Frais 1 % à l'achat et à la vente</span></div>
    ${iv.dc>0?`<div class="lrow2"><span>Ta position : ${fr.format(iv.dc)} DC</span><b class="num ${pnl>=0?'upc':'dnc'}">${eur(dcV)} (${pnl>=0?'+':''}${eur(pnl)})</b></div>`:''}
    <div class="row2"><button class="btn gold" data-act="dcbuy" ${S.cash>=INVAMT?'':'disabled'}>Acheter ${short2(INVAMT)} €</button><button class="btn" data-act="dcsell" ${iv.dc>0?'':'disabled'}>Tout vendre</button></div></section>
  <section class="inv7"><b>🖼️ NFT de Kevin</b><span class="note">Tu achètes un NFT au hasard. Dans 1 h, il est revendu : souvent pour rien, parfois ×5, très rarement ×20.</span>
    ${iv.nft.map(x=>`<div class="lrow2"><span>« ${esc(x.art)} »</span><span class="note num">${eur(x.amt)} · résultat dans ${tl(x)}</span></div>`).join('')}<button class="btn" data-act="nftbuy" ${S.cash>=INVAMT?'':'disabled'}>Acheter un NFT · ${short2(INVAMT)} €</button></section>
  <section class="inv7"><b>🚀 Start-up de Kevin</b><span class="note">Kevin cherche des investisseurs. Dans 3 h : faillite (le plus souvent), ×2, ×4… ou ×12.</span>
    ${iv.st.map(x=>`<div class="lrow2"><span>« ${esc(x.idea)} »</span><span class="note num">${eur(x.amt)} · verdict dans ${tl(x)}</span></div>`).join('')}<button class="btn" data-act="stbuy" ${S.cash>=INVAMT?'':'disabled'}>Investir · ${short2(INVAMT)} €</button></section>
  <section class="inv7 safe"><b>👵 Livret Mamie</b><span class="note">Ennuyeux mais sûr : +${String(D.INV.lv.rate*100).replace('.',',')} % par jour, bloqué ${D.INV.lv.days} jours.</span>
    ${r.lv.map(x=>`<div class="lrow2"><span class="num">${eur(x.amt)} → <b>${eur(x.v)}</b></span>${now()>=x.end?`<button class="btn sm gold" data-act="lvout" data-v="${x.id}">Retirer</button>`:`<span class="note">encore ${tl(x)}</span>`}</div>`).join('')}<button class="btn" data-act="lvin" ${S.cash>=INVAMT?'':'disabled'}>Placer · ${short2(INVAMT)} €</button></section>`;
  dcDraw()}
const coinD=()=>`<svg width="40" height="40" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="18" fill="#f2c14e"/><circle cx="20" cy="20" r="13" fill="none" stroke="#9a6512" stroke-width="1.5" stroke-dasharray="3 2"/><text x="20" y="25" text-anchor="middle" font-size="13" font-weight="800" font-family="Unbounded,sans-serif" fill="#3a2508">D</text></svg>`;
ACT.invamt=el=>{INVAMT=+el.dataset.v;render()};
const inv7=(n,p,msg)=>async()=>{try{const r=await api(n,p());toast(msg(r));snd('chip');render()}catch(e){}};
ACT.dcbuy=inv7('dcBuy',()=>({amt:INVAMT}),r=>'Tu as '+fr.format(r.coins)+' DaronCoin. Bonne chance.');
ACT.dcsell=inv7('dcSell',()=>({part:1}),r=>(r.pnl>=0?'📈 Vendu avec ':'📉 Vendu avec ')+(r.pnl>=0?'+':'')+eur(r.pnl));
ACT.nftbuy=inv7('nftBuy',()=>({amt:INVAMT}),r=>'🖼️ Tu possèdes « '+r.art+' ». Verdict dans 1 h.');
ACT.stbuy=inv7('stBuy',()=>({amt:INVAMT}),r=>'🚀 Tu finances « '+r.idea+' ». Verdict dans 3 h.');
ACT.lvin=inv7('lvDeposit',()=>({amt:INVAMT}),()=>'👵 Mamie garde ton argent bien au chaud.');
ACT.lvout=async el=>{try{const r=await api('lvWithdraw',{id:el.dataset.v});toast('👵 +'+eur(r.v));render()}catch(e){}};

/* ---------- Chat : couleur du pseudo, surnom, prestige ---------- */
{const _c=chatUI;chatUI=function(){_c();$$('#chatL .cmsg').forEach((el,i)=>{const m=CHAT[i];if(!m||m.sys)return;const b=el.querySelector('.w b');if(!b||b.dataset.v7)return;b.dataset.v7=1;if(m.nc)b.className=ncCls(m.nc);
  if(m.pr)b.insertAdjacentHTML('afterend',` <span class="prb">⭐${m.pr}</span>`);if(m.nick)b.insertAdjacentHTML('afterend',` <span class="nickt">« ${esc(m.nick)} »</span>`)})}}

/* ---------- Quoi de neuf ---------- */
NEWS.length=0;NEWS.push(['🧱','Tour de lingots refaite','12 étages, combo « Parfait », étages piégés et un coffre au sommet. Elle est (vraiment) dure maintenant.'],
  ['🍭','Bonbons Fous','Machine à cascades : les bonbons explosent, les bombes multiplient jusqu\'à ×100. Bonus achetable.'],['🎣','Pêche Miraculeuse','Le pêcheur ramasse tous les poissons en tours gratuits.'],
  ['🔐','Coffre-fort en direct','Tout le monde cherche le même code. Le premier qui trouve rafle la cagnotte.'],['💰','3 jackpots progressifs','Mini, Majeur et Méga peuvent tomber sur n\'importe quelle mise.'],
  ['💎','Statut VIP','Plus tu mises, plus tu montes : cashback chaque lundi et coffre du jour boosté.'],['🏆','Saisons de 30 jours + passe','50 paliers à débloquer, un classement, des trophées.'],
  ['⭐','Prestige','Remets-toi à zéro contre +10 % d\'XP pour toujours et un badge.'],['🥊','Boss de la semaine','Gérard l\'huissier : tout le monde le frappe en jouant, le butin est partagé.'],
  ['🍾','Le Carré VIP','Flambe des bouteilles jusqu\'à 100 milliards. Le DJ te clashe dans le chat.'],['🏎️','Garage & montres','Lambordini, Rolax, Patek Philou… visibles sur ton profil.'],
  ['🤡','Humilier un pote','Colle-lui un surnom ridicule pendant 24 h.'],['📉','Placements foireux','DaronCoin, NFT de Kevin, start-ups… et le Livret Mamie.'],
  ['⚖️','Le casino est plus juste','On a corrigé les failles : plus aucun jeu ne rapporte à coup sûr. Les récompenses (missions, défis, coffres) grandissent avec ta fortune.'],
  ['🚀','Crash réparé','Ton clic sur « Encaisser » compte au moment où tu appuies, même avec une connexion lente.']);
