/* ====================== V7 : nouveaux jeux ====================== */
GAMES.forEach(g=>delete g.nw);
{const lg=GAMES.find(g=>g.id==='lingots');if(lg)Object.assign(lg,{nm:'Tour de lingots',tg:'12 étages, un coffre au sommet. Vraiment dur.',nw:1});}
GAMES.unshift(
  {id:'bonbons',ic:'🍭',nm:'Bonbons Fous',tg:'Cascades, bombes jusqu\'à ×100',c:'#ff5fb2',nw:1,lv:2,cat:'machines'},
  {id:'peche',ic:'🎣',nm:'Pêche Miraculeuse',tg:'Le pêcheur ramasse tous les poissons',c:'#1a8fc4',nw:1,lv:3,cat:'machines'},
  {id:'cf',ic:'🔐',nm:'Coffre-fort',tg:'Trouve le code avant les autres',c:'#5a6b7a',nw:1,lv:4,cat:'special',b:'live'});
Object.assign(ST,{bonbons:100,peche:100,lingots:ST.lingots||50});

/* ---------- Dessins des symboles ---------- */
const CANDY={
  heart:'<path d="M50 84C22 64 12 48 12 34a18 18 0 0 1 38-8 18 18 0 0 1 38 8c0 14-10 30-38 50z" fill="#ff3b5c"/><path d="M28 26c6-6 14-4 16 2" stroke="#ffd0d8" stroke-width="5" fill="none" stroke-linecap="round"/>',
  star:'<path d="M50 8l11 25 27 3-20 18 6 27-24-14-24 14 6-27L12 36l27-3z" fill="#a35cf0" stroke="#6b2fb0" stroke-width="3"/><circle cx="40" cy="36" r="5" fill="#e6d2ff"/>',
  gem:'<path d="M50 10l34 26-34 54-34-54z" fill="#39d98a"/><path d="M16 36h68M34 36l16 54 16-54M34 36l16-26 16 26" fill="none" stroke="#0d5a35" stroke-width="2.5" opacity=".6"/>',
  drop:'<path d="M50 8C66 34 78 48 78 64a28 28 0 0 1-56 0c0-16 12-30 28-56z" fill="#4cc9f0"/><ellipse cx="40" cy="58" rx="7" ry="11" fill="#e3fcff" opacity=".7"/>',
  sq:'<rect x="16" y="16" width="68" height="68" rx="16" fill="#ffb02e"/><rect x="16" y="16" width="68" height="68" rx="16" fill="none" stroke="#b86e00" stroke-width="4"/><path d="M30 34h40M30 50h40M30 66h40" stroke="#ffd98a" stroke-width="5" stroke-linecap="round"/>',
  ring:'<circle cx="50" cy="50" r="36" fill="#ff8ad0"/><circle cx="50" cy="50" r="13" fill="#2a0f22"/><path d="M28 32l6 4M66 28l-2 6M72 58l-6-2M36 72l4-5M56 74l-1-6" stroke="#fff" stroke-width="4" stroke-linecap="round"/>',
  bean:'<path d="M26 66c-14-20 0-50 26-50s36 22 26 38c-6 10-18 8-26 16s-18 8-26-4z" fill="#5fd39a"/><path d="M38 34c6-6 16-6 20 0" stroke="#d9ffe9" stroke-width="5" fill="none" stroke-linecap="round"/>',
  mint:'<circle cx="50" cy="50" r="34" fill="#e3fcff"/><path d="M50 16a34 34 0 0 1 0 68M50 16a34 34 0 0 0 0 68" fill="none"/><path d="M50 16c18 10 18 24 0 34s-18 24 0 34" stroke="#ff4d6d" stroke-width="7" fill="none"/>',
  lolly:'<rect x="46" y="54" width="8" height="40" rx="3" fill="#f6efe4"/><circle cx="50" cy="38" r="30" fill="#ff5fb2"/><path d="M50 38m-22 0a22 22 0 1 0 44 0a16 16 0 1 0-32 0a10 10 0 1 0 20 0" fill="none" stroke="#fff" stroke-width="5"/>',
  bomb:'<circle cx="48" cy="56" r="32" fill="#2a1d33" stroke="#ff5fb2" stroke-width="4"/><path d="M62 28l10-12" stroke="#c9a46a" stroke-width="5"/><circle cx="74" cy="14" r="6" fill="#ffb02e"/><path d="M34 44c4-6 10-8 14-8" stroke="#fff" stroke-width="5" fill="none" stroke-linecap="round" opacity=".6"/>'};
const csym=(k,cls='')=>{if(k.startsWith('bomb:')){const v=k.slice(5);return`<span class="cs bomb ${cls}"><svg viewBox="0 0 100 100" aria-hidden="true">${CANDY.bomb}</svg><b>×${v}</b></span>`}return`<span class="cs ${cls}"><svg viewBox="0 0 100 100" aria-hidden="true">${CANDY[k]||''}</svg></span>`};
const FISHART={
  boat:'<path d="M10 58h80l-12 22H22z" fill="#c3343a"/><rect x="46" y="18" width="5" height="40" fill="#5c3a1a"/><path d="M51 20l26 32H51z" fill="#f6efe4"/><path d="M8 82c10-4 20 4 30 0s20 4 30 0 20 4 26 0" stroke="#4cc9f0" stroke-width="4" fill="none"/>',
  rod:'<path d="M20 86L78 14" stroke="#7a4f0c" stroke-width="6" stroke-linecap="round"/><circle cx="34" cy="68" r="9" fill="#9aa3b5" stroke="#3a4652" stroke-width="3"/><path d="M78 14v56" stroke="#e3fcff" stroke-width="1.5"/><path d="M78 70c0 8 8 8 8 2" stroke="#c8d6e2" stroke-width="3" fill="none"/>',
  box:'<rect x="14" y="36" width="72" height="44" rx="6" fill="#2d6cdf"/><rect x="14" y="26" width="72" height="16" rx="5" fill="#4c8af0"/><rect x="44" y="34" width="12" height="12" rx="2" fill="#f2c14e"/><path d="M24 56h52M24 68h52" stroke="#1a3f8a" stroke-width="3"/>',
  bob:'<circle cx="50" cy="56" r="26" fill="#f6efe4"/><path d="M24 56a26 26 0 0 1 52 0z" fill="#ff4d5e"/><rect x="47" y="12" width="6" height="20" fill="#1a1a1a"/><path d="M24 56h52" stroke="#1a1a1a" stroke-width="3"/>',
  Q:'<text x="50" y="72" text-anchor="middle" font-family="Unbounded,sans-serif" font-weight="800" font-size="58" fill="#a35cf0" stroke="#3d1a6b" stroke-width="3">Q</text>',
  J:'<text x="50" y="72" text-anchor="middle" font-family="Unbounded,sans-serif" font-weight="800" font-size="58" fill="#39d98a" stroke="#0d4a2a" stroke-width="3">J</text>',
  fish:'<path d="M14 50c14-20 44-24 62 0-18 24-48 20-62 0z" fill="#ffb02e"/><path d="M76 50l16-14v28z" fill="#e08a1e"/><circle cx="30" cy="46" r="4" fill="#1a1a1a"/><path d="M44 38c4 8 4 16 0 24" stroke="#c46a00" stroke-width="3" fill="none"/>',
  man:'<circle cx="50" cy="34" r="16" fill="#e8b98f"/><path d="M30 30c0-14 40-14 40 0z" fill="#2d6cdf"/><rect x="26" y="26" width="48" height="6" rx="3" fill="#1a3f8a"/><path d="M24 92c2-24 14-32 26-32s24 8 26 32z" fill="#f2c14e"/><path d="M44 40c4 3 8 3 12 0" stroke="#5c3a1a" stroke-width="2.5" fill="none"/>',
  hook:'<path d="M54 10v46a18 18 0 1 1-36 0" stroke="#c8d6e2" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M18 56l-6-10" stroke="#c8d6e2" stroke-width="7" stroke-linecap="round"/><circle cx="54" cy="10" r="6" fill="#f2c14e"/>'};
const fsym=(k,bet)=>{if(k.startsWith('fish:')){const v=+k.slice(5);return`<span class="fsy fishv"><svg viewBox="0 0 100 100" aria-hidden="true">${FISHART.fish}</svg><b>${short2(v*bet)}</b></span>`}return`<span class="fsy s-${k}"><svg viewBox="0 0 100 100" aria-hidden="true">${FISHART[k]||''}</svg></span>`};
const short2=n=>n>=1e9?(n/1e9).toFixed(n>=1e10?0:1).replace('.',',')+' Md':n>=1e6?(n/1e6).toFixed(n>=1e7?0:1).replace('.',',')+' M':n>=1e4?Math.round(n/1e3)+' k':fr.format(Math.round(n));
Object.assign(GART,{
  bonbons:sv(`<rect x="0" y="0" width="100" height="80" fill="#3a0f2a"/>`+[[18,22,'heart'],[50,18,'star'],[82,24,'drop'],[26,56,'ring'],[58,54,'gem'],[84,58,'bean']].map(([x,y,k])=>`<g transform="translate(${x-13} ${y-13}) scale(.26)">${CANDY[k]}</g>`).join('')+`<g transform="translate(34 2) scale(.32)">${CANDY.lolly}</g>`),
  peche:sv(`<rect x="0" y="0" width="100" height="80" fill="#0d3b5a"/><path d="M0 30c12-6 24 6 36 0s24 6 36 0 20 4 28 0V80H0z" fill="#135d7a"/><g transform="translate(46 0) scale(.5)">${FISHART.man}</g><g transform="translate(6 40) scale(.38)">${FISHART.fish}</g><g transform="translate(58 46) scale(.32)">${FISHART.fish}</g><text x="22" y="76" font-size="9" font-weight="900" font-family="sans-serif" fill="#ffe39a">×50</text>`),
  cf:sv(`<rect x="18" y="10" width="64" height="60" rx="8" fill="#5a6b7a" stroke="#c8d6e2" stroke-width="2"/><circle cx="50" cy="40" r="16" fill="#3a4652" stroke="#f2c14e" stroke-width="3"/><path d="M50 26v6M50 48v6M36 40h6M58 40h6" stroke="#f2c14e" stroke-width="3"/><rect x="26" y="72" width="48" height="6" rx="2" fill="#2e3a44"/><text x="50" y="44" text-anchor="middle" font-size="9" font-weight="900" font-family="monospace" fill="#ffe39a">?</text>`)});

/* ======================= TOUR DE LINGOTS ======================= */
const LG2=D.LG2;
let LGT={phase:'idle',bet:0,f:0,w:LG2.w0,x:0,rows:[],t0:0,ph:0,inv:false,traps:[],combo:0,busy:false,msg:'Arrête la barre pile au-dessus de l\'étage du dessous. Ce qui dépasse tombe. 3 « Parfait » d\'affilée = ton lingot regrandit.',cls:''};
BUSY.push(()=>LGT.phase==='run'||LGT.busy);
GAME_VIEW.lingots=el=>{const run=LGT.phase==='run',m=LG2.mult;
  el.innerHTML=`<div class="lg7">
    <div class="lgstats"><div><span>MISE</span><b class="num">${eur(run?LGT.bet:ST.lingots)}</b></div><div><span>ÉTAGE</span><b class="num">${LGT.f} / ${LG2.floors}</b></div><div class="cmb"><span>COMBO</span><i>${[0,1,2].map(i=>`<em class="${i<LGT.combo?'on':''}"></em>`).join('')}</i></div></div>
    <div class="lgwrap7"><div class="lgboard7" id="lgB" style="--cols:${LG2.cols};--rows:${LG2.floors+1}">
      <div class="lgchest ${LGT.f>=LG2.floors?'open':''}" style="grid-row:1"><svg viewBox="0 0 80 40" aria-hidden="true"><rect x="10" y="10" width="60" height="28" rx="5" fill="#3a2508" stroke="#f2c14e" stroke-width="2"/><rect x="10" y="6" width="60" height="12" rx="5" fill="url(#gGoldUI)"/><circle cx="40" cy="26" r="6" fill="#1a1006" stroke="#f2c14e" stroke-width="2"/></svg><span>COFFRE ×${m[LG2.floors]}</span></div>
      ${Array.from({length:LG2.floors},(_,r)=>{const f=LG2.floors-1-r,R=LGT.rows[f],trap=LGT.traps.includes(f);return`<div class="lgrow7 ${f===LGT.f&&run?'cur':''} ${trap?'trap':''}" style="grid-row:${r+2}">${R?`<i class="bar7" style="left:calc(${R[0]} * 100% / ${LG2.cols});width:calc(${R[1]} * 100% / ${LG2.cols})"></i>`:''}${trap&&!R?'<span class="traptag">PIÈGE · SENS INVERSE</span>':''}</div>`}).join('')}
      <i class="bar7 mov" id="lgM" hidden></i></div>
    <div class="lgladder7">${m.map((x,f)=>f<LG2.min?null:`<span class="${f===LGT.f?'on':f<LGT.f?'ok':''} ${LGT.traps.includes(f-1)?'tr':''}" style="grid-row:${LG2.floors-f+2}">${f===LG2.floors?'🔓 ':''}×${String(x).replace('.',',')}</span>`).filter(Boolean).join('')}</div></div>
    <div class="msg ${LGT.cls}">${LGT.msg}</div>
    ${run?`<div class="row2 lgbtns"><button class="btn big cashb" data-act="lgout" ${LGT.f>=LG2.min&&!LGT.busy?'':'disabled'}>Encaisser<small class="num">${LGT.f>=LG2.min?eur(LGT.bet*m[LGT.f]):'dès '+LG2.min+' étages'}</small></button><button class="btn gold big poser" data-act="lgtap" ${LGT.busy?'disabled':''}>POSER</button></div>`
    :`${stakeUI('lingots')}<button class="btn gold big" data-act="lggo">Commencer · <span data-sl="lingots">${eur(ST.lingots)}</span></button><p class="note">Plus tu montes, plus la barre va vite. Deux étages piégés partent dans l'autre sens. Le coffre au 12e étage paie ×${m[LG2.floors]}.</p>`}</div>`;
  lg7Loop()};
let lg7On=false;
function lg7Loop(){if(lg7On)return;lg7On=true;const f=()=>{const mv=$('#lgM'),b=$('#lgB');if(!mv||!b){lg7On=false;return}
  if(LGT.phase==='run'&&!LGT.busy){const x=D.lg2Pos(now()-LGT.t0,LGT.w,LGT.f,LGT.ph,LGT.inv),rh=b.clientHeight/(LG2.floors+1);mv.hidden=false;mv.style.left=`calc(${x} * 100% / ${LG2.cols})`;mv.style.width=`calc(${LGT.w} * 100% / ${LG2.cols})`;mv.style.top=((LG2.floors-LGT.f)*rh)+'px';mv.style.height=rh+'px';mv.classList.toggle('inv',LGT.inv)}
  else if(LGT.phase!=='run')mv.hidden=true;requestAnimationFrame(f)};requestAnimationFrame(f)}
function lg7Drop(x,w,f){const b=$('#lgB');if(!b||w<=0)return;const rh=b.clientHeight/(LG2.floors+1),cw=b.clientWidth/LG2.cols;const p=document.createElement('i');p.className='bar7 fall';p.style.cssText=`left:${x*cw}px;width:${w*cw}px;top:${(LG2.floors-f)*rh}px;height:${rh}px`;b.appendChild(p);setTimeout(()=>p.remove(),900)}
ACT.lggo=async()=>{if(!canBet(ST.lingots))return;let r;try{r=await api('lgStart',{amt:ST.lingots})}catch(e){return}
  Object.assign(LGT,{phase:'run',bet:ST.lingots,f:0,w:r.w,x:0,rows:[],t0:r.t0,ph:r.ph,inv:r.inv,traps:r.traps,combo:0,msg:'Tape « POSER » (ou le plateau) au bon moment !',cls:''});snd('pop');render()};
ACT.lgtap=async()=>{if(LGT.phase!=='run'||LGT.busy)return;LGT.busy=true;holdCash=1;const ms=now()-LGT.t0,xs=D.lg2Pos(ms,LGT.w,LGT.f,LGT.ph,LGT.inv),wb=LGT.w;let r;try{r=await api('lgTap',{ms})}catch(e){LGT.busy=false;release();return}
  if(r.lose){const f=LGT.f;LGT.phase='idle';LGT.busy=false;LGT.msg='Raté ! La tour s\'effondre au '+(f+1)+'e étage. Perdu '+eur(LGT.bet)+'.';LGT.cls='lose';render();lg7Drop(xs,wb,f);snd('boom');shake();vib([60,40,120]);release();return}
  const cut=wb-r.w+(r.grow?1:0);if(cut>0&&LGT.f>0){const px=LGT.x;const left=Math.max(0,px-xs),right=Math.max(0,(xs+wb)-(px+wb));if(left)setTimeout(()=>lg7Drop(xs,left,r.f-1),30);if(right)setTimeout(()=>lg7Drop(px+wb,right,r.f-1),30)}
  LGT.rows[r.f-1]=[r.x,r.w];LGT.x=r.x;LGT.w=r.w;LGT.f=r.f;LGT.combo=r.combo||0;snd(r.perfect?'coin':'tick');vib(r.perfect?[20,30,20]:20);
  if(r.done){LGT.phase='idle';LGT.busy=false;LGT.msg=(r.f>=LG2.floors?'🔓 COFFRE OUVERT ! ':'')+'Encaissé '+x2(r.m)+' : +'+eur(r.pay-LGT.bet);LGT.cls='win';render();burst(r.f>=LG2.floors?80:40);snd('big');release();return}
  LGT.t0=r.t0;LGT.ph=r.ph;LGT.inv=r.inv;LGT.busy=false;LGT.msg=r.grow?'✨ TRIPLE PARFAIT ! Ton lingot regrandit.':r.perfect?'Parfait ! Combo '+LGT.combo+'/3.':cut>0?`${cut} morceau${cut>1?'x':''} tombé${cut>1?'s':''}… Il reste ${r.w} de large.`:'Bien posé.';
  if(r.inv)LGT.msg+=' ⚠️ Étage piégé : la barre part dans l\'autre sens !';LGT.cls=r.perfect?'win':'';render();release()};
ACT.lgout=()=>play(async()=>{if(LGT.phase!=='run'||LGT.f<LG2.min)return;const r=await api('lgOut');LGT.phase='idle';LGT.msg='Encaissé '+x2(r.m)+' au '+r.f+'e étage : '+(r.pay>=LGT.bet?'+':'')+eur(r.pay-LGT.bet);LGT.cls=r.pay>=LGT.bet?'win':'';render();if(r.pay>LGT.bet)burst(r.m>=2?30:12);snd('win')});
document.addEventListener('pointerdown',e=>{if(e.target.closest('#lgB')&&LGT.phase==='run')ACT.lgtap()});

/* ======================= BONBONS FOUS ======================= */
let BF={busy:false,grid:null,msg:'8 bonbons identiques n\'importe où = gain. Ils explosent, d\'autres tombent. 4 sucettes = 10 tours gratuits avec bombes.',cls:'',fs:0,fsTot:0,total:0,turbo:false,mult:0};
BUSY.push(()=>BF.busy);
const bfRand=()=>{const ks=D.BF.sym.map(s=>s.k);return Array.from({length:6},()=>Array.from({length:5},()=>ks[Math.random()*ks.length|0]))};
function bfGridHTML(g,hit,fresh){return`<div class="bfgrid" id="bfG">${g.map((col,c)=>`<div class="bfcol">${col.map((s,r)=>csym(s,(hit&&hit.includes(s)?'hit ':'')+(fresh&&fresh[c]&&r<fresh[c]?'fresh':'')))
  .join('')}</div>`).join('')}</div>`}
GAME_VIEW.bonbons=el=>{if(!BF.grid)BF.grid=bfRand();const b=ST.bonbons;
  el.innerHTML=`<div class="bf7 ${BF.fs?'fsmode':''}"><div class="bfhead"><b>BONBONS FOUS</b>${BF.fs?`<span class="fsb">TOURS GRATUITS ${BF.fsN}/${BF.fsTot}</span>`:'<span class="note">Cascades · bombes ×2 à ×100</span>'}</div>
    ${bfGridHTML(BF.grid)}<div class="bfwin"><span>${BF.mult>1?`<b class="bm">×${BF.mult}</b>`:''}</span><b class="num" id="bfW">${BF.total?'+'+eur(BF.total):''}</b></div>
    <div class="msg ${BF.cls}">${BF.msg}</div>
    ${stakeUI('bonbons')}
    <div class="row2"><button class="btn gold big" data-act="bfgo" ${BF.busy?'disabled':''}>Jouer · <span data-sl="bonbons">${eur(b)}</span></button><button class="btn big" data-act="bfbuy" ${BF.busy?'disabled':''}>Bonus<small class="num">${eur(b*D.BF.buy)}</small></button></div>
    <label class="tgl"><input type="checkbox" data-act="bfturbo" ${BF.turbo?'checked':''}> Mode rapide</label>
    <details class="note"><summary>Table des gains</summary>${D.BF.sym.map(s=>`<div class="pt">${csym(s.k)}<span>8-9 : ×${s.p[0]} · 10-11 : ×${s.p[1]} · 12+ : ×${s.p[2]}</span></div>`).join('')}<div class="pt">${csym('lolly')}<span>4 : ×3 + 10 tours · 5 : ×5 · 6 : ×100</span></div></details></div>`};
ACT.bfturbo=el=>{BF.turbo=el.checked};
async function bfAnim(r){const sp=BF.turbo?.35:1;let shownTot=0;
  for(let i=0;i<r.spins.length;i++){const s=r.spins[i];if(s.free){BF.fs=1;BF.fsN=(BF.fsN||0)+1;BF.fsTot=r.fs;BF.mult=0}
    for(let k=0;k<s.steps.length;k++){const st=s.steps[k];const prev=k?s.steps[k-1]:null;
      BF.grid=st.grid;const fresh=prev?st.grid.map((col,c)=>prev.grid[c].filter(x=>prev.hit.includes(x)).length):null;
      const g=$('#bfG');if(g)g.outerHTML=bfGridHTML(st.grid,null,fresh||st.grid.map(()=>5));await sleep(T((k?380:520)*sp));
      if(st.win){const g2=$('#bfG');if(g2)g2.outerHTML=bfGridHTML(st.grid,st.hit);snd('coin');shownTot+=st.win;const w=$('#bfW');if(w)w.textContent='+'+eur(shownTot);await sleep(T(650*sp))}}
    if(s.mult>1&&s.base){BF.mult=s.mult;const w=$('#bfW');shownTot+=s.tot-s.base;if(w){w.parentElement.querySelector('span').innerHTML=`<b class="bm">×${s.mult}</b>`;w.textContent='+'+eur(shownTot)}snd('big');burst(12);await sleep(T(900*sp))}
    if(s.scWin){shownTot+=s.scWin;snd('level');toast('🍭 '+s.sc+' sucettes : tours gratuits !');await sleep(T(900))}
    if(s.retrig){toast('+'+s.retrig+' tours gratuits !');snd('level')}
    if(s.free)await sleep(T(250*sp))}}
async function bfRun(buy){if(BF.busy)return;const b=ST.bonbons,cost=buy?b*D.BF.buy:b;if(!canBet(cost))return;BF.busy=true;holdCash=1;Object.assign(BF,{fs:0,fsN:0,fsTot:0,total:0,mult:0,msg:buy?'Bonus acheté : 10 tours gratuits avec bombes !':'…',cls:''});render();
  let r;try{r=await api('bfSpin',{amt:b,buy:buy?1:0})}catch(e){BF.busy=false;release();render();return}
  await bfAnim(r);BF.total=r.total;BF.busy=false;BF.fs=0;const m=r.total/r.stake;BF.msg=r.total?`Gagné ${eur(r.total)}${r.fs?' avec '+r.fs+' tours gratuits':''} (×${(r.total/b).toFixed(1).replace('.',',')})`:'Pas de chance. Les bonbons te narguent.';BF.cls=r.total>r.stake?'win':r.total?'':'lose';
  render();if(m>=10){burst(60);snd('big')}else if(r.total>r.stake)snd('win');release()}
ACT.bfgo=()=>bfRun(false);
ACT.bfbuy=()=>{const b=ST.bonbons;modal(`<p class="mt">🍭 Acheter le bonus ?</p><p>Tu paies <b>${eur(b*D.BF.buy)}</b> (${D.BF.buy} × ta mise) et tu pars directement sur <b>10 tours gratuits</b> avec bombes multiplicatrices.</p><p class="note">Ça peut faire ×1000… ou presque rien.</p><div class="row2"><button class="btn" data-close>Non</button><button class="btn gold" data-act="bfbuyok">Acheter</button></div>`)};
ACT.bfbuyok=()=>{closeModal();bfRun(true)};

/* ======================= PÊCHE MIRACULEUSE ======================= */
let PM={busy:false,grid:null,msg:'3 hameçons = 10 tours gratuits. En tours gratuits, chaque pêcheur ramasse tous les poissons à l\'écran.',cls:'',fs:0,fsN:0,fsTot:0,cm:1,total:0,lines:[]};
BUSY.push(()=>PM.busy);
const pmRand=()=>{const ks=['boat','rod','box','bob','Q','J','J','Q','fish:1','fish:.5'];return Array.from({length:5},()=>Array.from({length:3},()=>ks[Math.random()*ks.length|0]))};
function pmGridHTML(g,hits,spin){const hs=new Set(hits||[]);return`<div class="pmgrid ${spin?'spin':''}" id="pmG">${g.map((col,c)=>`<div class="pmcol">${col.map((s,r)=>`<div class="pmc ${hs.has(c+'-'+r)?'hit':''}">${fsym(s,PM.bet||ST.peche)}</div>`).join('')}</div>`).join('')}</div>`}
GAME_VIEW.peche=el=>{if(!PM.grid)PM.grid=pmRand();
  el.innerHTML=`<div class="pm7 ${PM.fs?'fsmode':''}"><div class="pmhead"><b>PÊCHE MIRACULEUSE</b>${PM.fs?`<span class="fsb">TOURS GRATUITS ${PM.fsN}/${PM.fsTot}${PM.cm>1?' · ×'+PM.cm:''}</span>`:'<span class="note">10 lignes · poissons jusqu\'à ×10</span>'}</div>
    <div class="pmsea">${pmGridHTML(PM.grid)}</div><div class="bfwin"><span></span><b class="num" id="pmW">${PM.total?'+'+eur(PM.total):''}</b></div>
    <div class="msg ${PM.cls}">${PM.msg}</div>${stakeUI('peche')}
    <button class="btn gold big" data-act="pmgo" ${PM.busy?'disabled':''}>Lancer la ligne · <span data-sl="peche">${eur(ST.peche)}</span></button>
    <details class="note"><summary>Table des gains (pour une mise de ${eur(ST.peche)})</summary>${D.PM.sym.map(s=>`<div class="pt">${fsym(s.k,ST.peche)}<span>3 : ${short2(s.p[0]*ST.peche/10)} · 4 : ${short2(s.p[1]*ST.peche/10)} · 5 : ${short2(s.p[2]*ST.peche/10)}</span></div>`).join('')}<div class="pt">${fsym('man',1)}<span>Joker. En tours gratuits : ramasse la valeur de tous les poissons. Tous les 4 pêcheurs : +10 tours et multiplicateur ×2, ×3 puis ×10.</span></div><div class="pt">${fsym('hook',1)}<span>3 hameçons : 10 tours gratuits</span></div></details></div>`};
async function pmAnim(r){let shown=0;PM.bet=r.bet;
  for(const s of r.spins){if(s.free){PM.fs=1;PM.fsN++;PM.fsTot=r.fs;PM.cm=s.cm||1;const h=$('.pmhead .fsb');if(h)h.textContent=`TOURS GRATUITS ${PM.fsN}/${PM.fsTot}${PM.cm>1?' · ×'+PM.cm:''}`;else render()}
    const g=$('#pmG');if(g){g.outerHTML=pmGridHTML(pmRand(),null,true)}snd('card');await sleep(T(420));
    const g2=$('#pmG');if(g2)g2.outerHTML=pmGridHTML(s.grid);PM.grid=s.grid;await sleep(T(250));
    const hits=[];s.lines.forEach(([li,n])=>{for(let c=0;c<n;c++)hits.push(c+'-'+D.PM.lines[li][c])});
    if(s.win){const g3=$('#pmG');if(g3)g3.outerHTML=pmGridHTML(s.grid,hits);shown+=s.win;snd('coin');const w=$('#pmW');if(w)w.textContent='+'+eur(shown);await sleep(T(700))}
    if(s.col){const fishC=[],manC=[];s.grid.forEach((col,c)=>col.forEach((x,r)=>{if(x.startsWith('fish:'))fishC.push(c+'-'+r);if(x==='man')manC.push(c+'-'+r)}));const g4=$('#pmG');if(g4)g4.outerHTML=pmGridHTML(s.grid,[...fishC,...manC]);
      shown+=s.col;snd('big');toast('🎣 Le pêcheur ramasse '+eur(s.col)+(s.cm>1?' (×'+s.cm+')':''));const w=$('#pmW');if(w)w.textContent='+'+eur(shown);burst(10);await sleep(T(1000))}
    if(s.scWin){shown+=s.scWin;snd('level');toast('🪝 '+s.sc+' hameçons : 10 tours gratuits !');await sleep(T(1100))}
    if(s.retrig){toast('+10 tours · multiplicateur ×'+s.newCm+' !');snd('level');await sleep(T(700))}}}
ACT.pmgo=async()=>{if(PM.busy||!canBet(ST.peche))return;PM.busy=true;holdCash=1;Object.assign(PM,{fs:0,fsN:0,fsTot:0,cm:1,total:0,msg:'…',cls:''});render();let r;try{r=await api('pmSpin',{amt:ST.peche})}catch(e){PM.busy=false;release();render();return}
  await pmAnim(r);PM.total=r.total;PM.busy=false;PM.fs=0;PM.msg=r.total?`Belle prise : ${eur(r.total)}${r.fs?' en '+r.fs+' tours gratuits':''} (×${(r.total/r.bet).toFixed(1).replace('.',',')})`:'Rien ne mord. Relance ta ligne.';PM.cls=r.total>r.bet?'win':r.total?'':'lose';render();if(r.total>=r.bet*20){burst(60);snd('big')}else if(r.total>r.bet)snd('win');release()};

/* ======================= COFFRE-FORT EN DIRECT ======================= */
let CFS=null,CFK='b',CFIN='',CFLAST=null;
GAME_VIEW.cf=el=>{const T=D.CF.find(c=>c.k===CFK),s=CFS&&CFS[CFK];
  el.innerHTML=`<div class="cf7"><div class="seg">${D.CF.map(c=>`<button data-act="cfk" data-v="${c.k}" class="${c.k===CFK?'on':''}">${c.nm.replace('Coffre ','')}</button>`).join('')}</div>
    <div class="cfsafe" style="--cc:${T.col}"><div class="cfpot"><span>CAGNOTTE</span><b class="num">${eur(s?s.pot:0)}</b><span class="note">${T.nm} · ${eur(T.fee)} l'essai · code de ${D.CF_LEN} chiffres tous différents</span></div>
      <svg class="cfdoor ${s&&s.win?'open':''}" viewBox="0 0 120 120" aria-hidden="true"><rect x="8" y="8" width="104" height="104" rx="14" fill="#3a4652" stroke="${T.col}" stroke-width="4"/><circle cx="60" cy="60" r="30" fill="#2e3a44" stroke="${T.col}" stroke-width="4"/>${Array.from({length:12},(_,i)=>`<path d="M60 34v6" transform="rotate(${i*30} 60 60)" stroke="${T.col}" stroke-width="3"/>`).join('')}<path d="M60 60l14-10" stroke="#f6efe4" stroke-width="4" stroke-linecap="round"/></svg></div>
    ${s&&s.win?`<div class="msg win">🔓 ${esc(s.win.p)} a trouvé le code <b class="num">${s.code}</b> et rafle ${eur(s.win.pot)} ! Nouveau coffre dans quelques secondes…</div>`
    :`<div class="cfcode" id="cfC">${Array.from({length:D.CF_LEN},(_,i)=>`<span class="${CFIN[i]?'on':''}">${CFIN[i]||''}</span>`).join('')}</div>
    <div class="cfpad">${[1,2,3,4,5,6,7,8,9,'⌫',0,'OK'].map(k=>`<button class="btn ${k==='OK'?'gold':''}" data-act="cfkey" data-v="${k}" ${typeof k==='number'&&CFIN.includes(String(k))?'disabled':''}>${k==='OK'?'Tenter · '+short2(T.fee)+' €':k}</button>`).join('')}</div>`}
    <p class="note">🟢 = bon chiffre à la bonne place · 🟡 = bon chiffre mal placé. Tout le monde voit les essais de tout le monde : sers-toi des indices des autres !</p>
    <div class="cflog">${s&&s.log.length?s.log.map(l=>`<div class="${l.uid===S.id?'mine':''}"><span>${esc(l.p)}</span><b class="num">${l.g.split('').map(x=>`<i>${x}</i>`).join('')}</b><span>${'🟢'.repeat(l.b)}${'🟡'.repeat(l.m)}${!l.b&&!l.m?'❌':''}</span></div>`).join(''):'<div class="empty">Personne n\'a encore tenté. Lance-toi !</div>'}</div></div>`};
ACT.cfk=el=>{CFK=el.dataset.v;CFIN='';render()};
ACT.cfkey=async el=>{const k=el.dataset.v;if(k==='⌫'){CFIN=CFIN.slice(0,-1);render();return}
  if(k==='OK'){if(CFIN.length!==D.CF_LEN){toast('Tape '+D.CF_LEN+' chiffres.');return}const T=D.CF.find(c=>c.k===CFK);if(!canBet(T.fee))return;const g=CFIN;CFIN='';try{const r=await api('cfGuess',{k:CFK,g});CFLAST=r;snd(r.b===D.CF_LEN?'big':r.b?'coin':'tick');if(r.b===D.CF_LEN)burst(80);else toast(g+' : '+r.b+' bien placé'+(r.b>1?'s':'')+', '+r.m+' mal placé'+(r.m>1?'s':''))}catch(e){CFIN=g}render();return}
  if(CFIN.length<D.CF_LEN&&!CFIN.includes(k)){CFIN+=k;snd('tick');const c=$('#cfC');if(c)c.innerHTML=Array.from({length:D.CF_LEN},(_,i)=>`<span class="${CFIN[i]?'on':''}">${CFIN[i]||''}</span>`).join('');el.disabled=true}};
on('cf',d=>{CFS=d;if(tab==='casino'&&sub.casino==='cf'&&!document.activeElement?.matches('input'))render()});
let CFJ=false;{const _gv=GAME_VIEW.cf;GAME_VIEW.cf=el=>{_gv(el);if(!CFJ){CFJ=true;api('cfJoin').then(r=>{CFS=r.cf;if(tab==='casino'&&sub.casino==='cf')render()}).catch(()=>{});onLeave(()=>{CFJ=false;quiet(api('cfLeave'))})}}}
