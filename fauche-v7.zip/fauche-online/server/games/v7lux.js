// V7 : dépenses de luxe — le Carré VIP, le garage, les montres, l'humiliation et les placements foireux.
const C = require('../core');
const db = require('../db');
const { D, rnd, pick, E } = C;
const io = () => C.io;
const now = () => Date.now();

/* ---------- Valeur des biens V7 dans la fortune ---------- */
C.extraWorth = u => { const d = u.d; let v = 0; if (d.gar && d.gar.length) for (const g of d.gar) v += D.luxValue(g);
  const iv = d.inv; if (iv) { v += (iv.dc || 0) * DC.p; if (iv.nft) for (const x of iv.nft) v += x.amt; if (iv.st) for (const x of iv.st) v += x.amt; if (iv.lv) for (const x of iv.lv) v += lvValue(x); } return Math.round(v); };
const inv = u => { u.d.inv = u.d.inv || { dc: 0, dcCost: 0, nft: [], st: [], lv: [] }; return u.d.inv; };

/* ---------- Le Carré VIP ---------- */
let FL = { k: '', rows: {} }, flDirty = false;
async function flLoad() { const k = C.weekKey(); if (FL.k !== k) { if (FL.k && flDirty) { flDirty = false; await db.kvSet('fl:' + FL.k, FL.rows); } FL = { k, rows: (await db.kvGet('fl:' + k)) || {} }; } return FL; }
setTimeout(() => flLoad().catch(() => {}), 3000); setInterval(() => { flLoad().catch(() => {}); if (flDirty) { flDirty = false; db.kvSet('fl:' + FL.k, FL.rows).catch(() => {}); } }, 30000);
C.api.bottle = async (u, p) => { const b = D.BOTTLES.find(x => x.id === p.id); if (!b) throw E('Bouteille inconnue.'); const n = Math.max(1, Math.min(20, Math.floor(+p.n || 1))); const cost = b.pr * n; C.pay(u, cost);
  u.d.flambe = (u.d.flambe || 0) + cost; await flLoad(); const r = FL.rows[u.id] = FL.rows[u.id] || { p: u.pseudo, v: 0, av: null }; r.p = u.pseudo; r.av = u.d.av.v2; r.v += cost; flDirty = true;
  C.track(u, 'play', 'lux', n); C.xp(u, Math.min(400, 10 + Math.round(Math.log10(cost) * 12)));
  if (b.title) { u.d.unlocks.push('t:' + b.title); if (!u.d.ach.includes('sultan')) { u.d.ach.push('sultan'); C.notify(u, { ic: '🍾', from: 'Succès débloqué', body: 'Le Sultan' }); } }
  let rained = 0; if (b.rain) { const others = [...C.users.values()].filter(o => o.id !== u.id && o.sockets.size); const each = others.length ? Math.floor(cost * b.rain / others.length) : 0;
    others.forEach(o => { C.money(o, each); C.notify(o, { ic: '🍾', from: u.pseudo + ' privatise la boîte', body: 'Il fait pleuvoir : +' + C.eur(each), big: 1 }); }); rained = each * others.length; }
  const others = [...C.users.values()].filter(o => o.id !== u.id).map(o => o.pseudo); const k = others.length ? pick(others) : 'Kevin';
  if (b.pr * n >= 25000 && C.sysChat) C.sysChat('🎧 DJ du Carré : « ' + pick(D.DJ).replace('{p}', u.pseudo).replace('{b}', (n > 1 ? n + ' × ' : '') + b.nm.toLowerCase()).replace('{k}', k) + ' »', { dj: 1 });
  if (cost >= 1e6) C.feed(`<b>${C.esc(u.pseudo)}</b> flambe ${C.eur(cost)} au Carré VIP`);
  if (b.id === 'b4') { C.events.wall = { pseudo: u.pseudo, av: u.d.av.v2, until: now() + 3600000 }; io() && io().emit('wall', C.events.wall); }
  return { cost, rained }; };
C.hello.push(() => ({ wall: C.events.wall && C.events.wall.until > now() ? C.events.wall : null }));
C.api.flTop = async u => { await flLoad(); return { rows: Object.entries(FL.rows).map(([id, r]) => ({ id: +id, pseudo: r.p, av: r.av, v: r.v })).sort((a, b) => b.v - a.v).slice(0, 20), me: u.d.flambe || 0 }; };

/* ---------- Garage et montres ---------- */
C.api.luxBuy = (u, p) => { const it = D.luxInfo(p.id); if (!it) throw E('Objet inconnu.'); u.d.gar = u.d.gar || []; if (u.d.gar.some(g => g.id === it.id)) throw E('Tu l\'as déjà.'); C.pay(u, it.pr);
  u.d.gar.push({ id: it.id, at: now(), pr: it.pr }); C.track(u, 'buy', null, 1); C.xp(u, 20); if (it.pr >= 1e6) { C.feed(`<b>${C.esc(u.pseudo)}</b> s'offre : ${it.nm}`); C.sysChat && C.sysChat(`🔑 ${u.pseudo} vient de s'offrir ${it.id[0] === 'c' ? 'une' : 'une montre'} ${it.nm} (${C.eur(it.pr)}).`); }
  return {}; };
C.api.luxSell = (u, p) => { const i = (u.d.gar || []).findIndex(g => g.id === p.id); if (i < 0) throw E('Tu ne l\'as pas.'); const v = D.luxValue(u.d.gar[i]); u.d.gar.splice(i, 1); C.money(u, v); return { v }; };
// les nouvelles voitures comptent pour les courses de rue
const _sr = C.api.streetRace; C.api.streetRace = (u, p) => { const best = (u.d.gar || []).map(g => D.CARS7.find(c => c.id === g.id)).filter(Boolean).sort((a, b) => b.sp - a.sp)[0];
  if (!best) return _sr(u, p); const old = Object.keys(D.CARS).filter(id => u.d.items.includes(id)).sort((a, c) => D.CARS[c] - D.CARS[a])[0];
  if (old && D.CARS[old] >= best.sp) return _sr(u, p); const b = D.BOTCARS[+p.i]; if (!b) throw E('Adversaire inconnu.'); const sp = best.sp, pr = sp / (sp + b[2]), odd = Math.max(1.01, Math.min(10, Math.floor(.94 / pr * 100) / 100));
  const amt = C.pay(u, p.amt), win = Math.random() < pr, pay = win ? Math.round(amt * odd) : 0; if (win) { u.d.street.w++; C.money(u, pay); } else u.d.street.l++; C.result(u, 'street', amt, pay); return { win, pay, car: best.id, carNm: best.nm, sp, odd }; };

/* ---------- Humiliation ---------- */
C.api.humiliate = async (u, p) => { const t = await C.getUser(+p.id); if (!t || t.id === u.id) throw E('Joueur introuvable.'); if (t.d.nick && t.d.nick.until > now()) throw E(t.pseudo + ' a déjà un surnom. Attends qu\'il expire.');
  let nick = String(p.nick || '').trim(); if (!D.NICKS.includes(nick)) { nick = C.clean(nick).slice(0, 24); if (nick.length < 3) throw E('Surnom trop court.'); }
  const price = D.humPrice(C.worth(u)); C.pay(u, price); t.d.nick = { t: nick, by: u.pseudo, byId: u.id, until: now() + 864e5, paid: price }; t.d.humis = (t.d.humis || 0) + 1; C.markDirty(t); C.push(t);
  if (!t.d.ach.includes('humi')) { t.d.ach.push('humi'); } C.track(u, 'play', 'humi', 1);
  C.notify(t, { ic: '🤡', from: u.pseudo, body: 'T\'a collé le surnom « ' + nick + ' » pendant 24 h. Tu peux payer ' + C.eur(price * 2) + ' pour l\'enlever.', keep: 1, go: 'moi' });
  C.sysChat && C.sysChat(`🤡 ${u.pseudo} a payé ${C.eur(price)} pour que ${t.pseudo} s'appelle désormais « ${nick} » pendant 24 h.`); return { price }; };
C.api.unhumiliate = u => { const n = u.d.nick; if (!n || n.until < now()) throw E('Tu n\'as pas de surnom.'); const cost = n.paid * 2; C.pay(u, cost); u.d.nick = null;
  C.sysChat && C.sysChat(`🧽 ${u.pseudo} a payé ${C.eur(cost)} pour effacer son surnom « ${n.t} ». La honte coûte cher.`); return { cost }; };

/* ---------- Placements foireux ---------- */
// DaronCoin : un cours partagé, très volatil, qui baisse un peu en moyenne
const DC = { p: 0.02, h: [] };
db.kvGet('dc7').then(v => { if (v && v.p) { DC.p = v.p; DC.h = v.h || []; } }).catch(() => {});
function gauss() { return Math.sqrt(-2 * Math.log(Math.random() || 1e-9)) * Math.cos(2 * Math.PI * Math.random()); }
let dcNews = '';
setInterval(() => { const sig = .012; let r = sig * gauss() - sig * sig / 2 - .000002;
  if (Math.random() < .001) { const up = Math.random() < .42; r += up ? Math.log(rnd(1.5, 3)) : Math.log(rnd(.05, .12)); dcNews = up ? pick(['Le Daron a tweeté une fusée. Le cours s\'envole !', 'Un rappeur parle du DaronCoin en story !', 'Tonton Michel a tout misé dessus !']) : pick(['Le Daron a vendu en douce. Panique !', 'Rumeur : le DaronCoin serait une arnaque (choquant).', 'La plateforme du Daron est en panne !']);
    io() && io().to('dc').emit('dcNews', { txt: dcNews, up }); }
  DC.p = Math.min(50, Math.max(.0001, DC.p * Math.exp(r))); DC.h.push(+DC.p.toPrecision(5)); if (DC.h.length > 180) DC.h.shift(); io() && io().to('dc').emit('dc', { p: DC.p }); }, 5000);
setInterval(() => db.kvSet('dc7', DC).catch(() => {}), 60000);
C.api.dcJoin = (u, p, s) => { s && s.join('dc'); return { p: DC.p, h: DC.h, news: dcNews, inv: inv(u) }; };
C.api.dcLeave = (u, p, s) => { s && s.leave('dc'); return {}; };
C.api.dcBuy = (u, p) => { const amt = C.pay(u, p.amt), iv = inv(u), net = amt * (1 - D.INV.dc.fee); iv.dc += net / DC.p; iv.dcCost += amt; C.track(u, 'play', 'invest', 1); C.markDirty(u); return { coins: iv.dc }; };
C.api.dcSell = (u, p) => { const iv = inv(u); const part = Math.max(0, Math.min(1, +p.part || 1)); const coins = iv.dc * part; if (coins <= 0) throw E('Tu n\'as pas de DaronCoin.');
  const val = Math.floor(coins * DC.p * (1 - D.INV.dc.fee)), cost = iv.dcCost * part; iv.dc -= coins; iv.dcCost -= cost; C.money(u, val); C.result(u, 'invest', Math.round(cost), val);
  if (val < cost * .1 && cost > 1000 && !u.d.ach.includes('dcrug')) { u.d.ach.push('dcrug'); C.notify(u, { ic: '📉', from: 'Succès honteux débloqué', body: 'Rug pull' }); }
  return { val, pnl: val - Math.round(cost) }; };
// NFT et start-up : tu paies, le résultat tombe plus tard
function drawOut(list) { let r = Math.random(); for (const [m, pr] of list) { if (r < pr) return m; r -= pr; } return list[0][0]; }
C.api.nftBuy = (u, p) => { const amt = C.pay(u, p.amt), iv = inv(u); if (iv.nft.length >= 5) { C.money(u, amt); throw E('5 NFT en attente maximum.'); } const art = pick(D.INV.nft.arts) + ' #' + (1 + Math.random() * 9999 | 0);
  iv.nft.push({ id: now() + '' + Math.random(), amt, art, at: now(), end: now() + D.INV.nft.h * 3600000 }); C.track(u, 'play', 'invest', 1); return { art }; };
C.api.stBuy = (u, p) => { const amt = C.pay(u, p.amt), iv = inv(u); if (iv.st.length >= 3) { C.money(u, amt); throw E('3 start-ups en attente maximum.'); } const idea = pick(D.INV.st.ideas);
  iv.st.push({ id: now() + '' + Math.random(), amt, idea, at: now(), end: now() + D.INV.st.h * 3600000 }); C.track(u, 'play', 'invest', 1); return { idea }; };
C.api.lvDeposit = (u, p) => { const amt = C.pay(u, p.amt), iv = inv(u); if (iv.lv.length >= 5) { C.money(u, amt); throw E('5 livrets maximum.'); } iv.lv.push({ id: now() + '' + Math.random(), amt, at: now(), end: now() + D.INV.lv.days * 864e5 }); return {}; };
const lvValue = x => Math.round(x.amt * Math.pow(1 + D.INV.lv.rate, Math.min(D.INV.lv.days, (now() - x.at) / 864e5)));
C.api.lvWithdraw = (u, p) => { const iv = inv(u), i = iv.lv.findIndex(x => x.id === p.id); if (i < 0) throw E('Livret introuvable.'); const x = iv.lv[i]; if (now() < x.end) throw E('Mamie a dit : pas avant ' + Math.ceil((x.end - now()) / 864e5) + ' jour(s).');
  const v = lvValue(x); iv.lv.splice(i, 1); C.money(u, v); return { v }; };
function settleInv(u) { const iv = u.d.inv; if (!iv) return; const t = now();
  for (const [k, L] of [['nft', D.INV.nft.out], ['st', D.INV.st.out]]) { const done = iv[k].filter(x => x.end <= t); if (!done.length) continue; iv[k] = iv[k].filter(x => x.end > t);
    done.forEach(x => { const m = drawOut(L), v = Math.round(x.amt * m); if (v) C.money(u, v); C.result(u, 'invest', x.amt, v);
      const nm = k === 'nft' ? 'Ton NFT « ' + x.art + ' »' : 'La start-up « ' + x.idea + ' »';
      C.notify(u, { ic: k === 'nft' ? '🖼️' : '🚀', from: k === 'nft' ? 'NFT de Kevin' : 'Start-up de Kevin', body: m === 0 ? nm + ' ne vaut plus rien. Kevin ne répond plus.' : nm + ' rapporte ×' + String(m).replace('.', ',') + ' : +' + C.eur(v), keep: 1, big: m >= 4 ? 1 : 0 });
      if (m >= 10 && C.sysChat) C.sysChat(`🚀 Incroyable : ${nm.toLowerCase()} de ${u.pseudo} fait ×${m} (${C.eur(v)}). Kevin pleure de joie.`); }); C.markDirty(u); } }
setInterval(() => C.users.forEach(u => settleInv(u)), 20000);
C.api.invInfo = u => { settleInv(u); const iv = inv(u); return { inv: iv, dc: DC.p, lv: iv.lv.map(x => ({ ...x, v: lvValue(x) })) }; };
module.exports = { DC };
