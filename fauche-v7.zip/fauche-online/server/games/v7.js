// V7 : récompenses proportionnelles, VIP, jackpots progressifs, saisons + passe, prestige, événements, boss de la semaine, rivalités.
const C = require('../core');
const db = require('../db');
const { D, rnd, pick, shuffle, E } = C;
const io = () => C.io;
const now = () => Date.now();

/* ---------- Outils ---------- */
C.scaled = (u, base) => D.scaleCash(C.worth(u), base);
C.boostCap = (u, id) => { const b = D.BOOSTS.find(x => x.id === id); if (!b) return 0; const pr = D.boostPrice(b, C.worth(u)); return id === 'requin' ? pr * 3 : id === 'flambeur' ? Math.round(pr / 2) : pr; };
const casinoGame = g => !D.JP_EXCL.includes(g);

/* ---------- Missions, coffre, roue : récompenses selon la fortune ---------- */
C.api.mclaim = (u, p) => { const m = C.todayMissions(u).find(x => x.id === p.id), M = D.MISSIONS.find(x => x.id === p.id); if (!m || !M || m.c || m.p < M.n) throw E('Mission pas encore terminée.'); m.c = true;
  const amt = Math.round(C.scaled(u, M.rw) * (1 + (u.d.prestige || 0) * .05)); C.money(u, amt); C.xp(u, 50); return { amt }; };
C.api.wclaim = (u, p) => { const m = C.weekMissions(u).find(x => x.id === p.id), M = D.WMIS.find(x => x.id === p.id); if (!m || !M || m.c || m.p < M.n) throw E('Mission pas encore terminée.'); m.c = true;
  const amt = Math.round(C.scaled(u, M.rw) * (1 + (u.d.prestige || 0) * .05)); C.money(u, amt); C.xp(u, 200); return { amt }; };
const _chest = C.api.chest; C.api.chest = u => { const before = u.d.cash; const r = _chest(u); const vip = D.VIP[D.vipOf(u.d.wag)]; const want = Math.round(C.scaled(u, r.amt) * vip.chest); if (want > r.amt) C.money(u, want - r.amt); return { amt: want, vip: vip.nm }; };

/* ---------- Défis du Croupier V7 (une tentative, mise minimum, récompense selon ta fortune) ---------- */
C.chalOffer = u => { const ch = pick(D.CHAL7), R = C.scaled(u, 5000), min = D.nice(R / 8), F = D.nice((ch.p + .05) * R / (1 - ch.p)); return { game: ch.g, mult: ch.m, amt: R, min, fine: F }; };

/* ---------- VIP : cashback chaque lundi sur tes pertes de la semaine ---------- */
function vipSettle(u) { const wk = C.weekKey(); const v = u.d.vw; if (!v) { u.d.vw = { wk, net: 0 }; return; } if (v.wk === wk) return;
  const lvl = D.vipOf(u.d.wag), cb = D.VIP[lvl].cb, loss = Math.max(0, -v.net); u.d.vw = { wk, net: 0 };
  if (cb && loss > 0) { const amt = Math.round(loss * cb); C.money(u, amt); C.notify(u, { ic: '💎', from: 'VIP ' + D.VIP[lvl].nm, body: 'Ton cashback de la semaine : +' + C.eur(amt) + ' (' + (cb * 100).toString().replace('.', ',') + ' % de tes pertes)', keep: 1, big: 1 }); } }

/* ---------- Jackpots progressifs ---------- */
C.jp7 = Object.fromEntries(D.JP7.map(j => [j.k, j.seed]));
db.kvGet('jp7').then(v => { if (v) Object.assign(C.jp7, v); }).catch(() => {});
let jpT = null; function jpEmit() { if (jpT) return; jpT = setTimeout(() => { jpT = null; io() && io().emit('jp7', C.jp7); db.kvSet('jp7', C.jp7).catch(() => {}); }, 2500); }
C.hello.push(() => ({ jp7: C.jp7 }));
function jpRoll(u, stake) { for (const J of D.JP7) { const add = stake * J.share; C.jp7[J.k] += add; const p = Math.min(.25, add / C.jp7[J.k]);
    if (Math.random() < p) { const pot = Math.round(C.jp7[J.k]); C.jp7[J.k] = J.seed; u.d.jp7w = (u.d.jp7w || 0) + 1; C.money(u, pot); C.checkAch(u);
      io() && io().emit('jpWin', { k: J.k, nm: J.nm, pseudo: u.pseudo, amt: pot }); C.feed(`<b>${C.esc(u.pseudo)}</b> décroche le jackpot ${J.nm} : ${C.eur(pot)} !`);
      C.sysChat && C.sysChat(`💰 JACKPOT ${J.nm.toUpperCase()} ! ${u.pseudo} rafle ${C.eur(pot)} !`); C.notify(u, { ic: '💰', from: 'Jackpot ' + J.nm, body: '+' + C.eur(pot), big: 1, snd: 'big' }); break; } }
  jpEmit(); }

/* ---------- Saisons (classement aux points de saison) + passe de saison ---------- */
let SEA = { n: 0, rows: {}, info: null }, seaDirty = false;
const seaInfo = () => D.seasonOf(C.dkeyParis());
async function seaLoad() { const inf = seaInfo(); if (SEA.n !== inf.n) { if (SEA.n && seaDirty) { seaDirty = false; await db.kvSet('sea:' + SEA.n, SEA.rows); }
    const last = SEA.n || (await db.kvGet('sealast')); if (last && last !== inf.n) await seaAward(last); SEA = { n: inf.n, rows: (await db.kvGet('sea:' + inf.n)) || {}, info: inf }; await db.kvSet('sealast', inf.n); }
  SEA.info = inf; return SEA; }
async function seaAward(n) { if (await db.kvGet('seadone:' + n)) return; await db.kvSet('seadone:' + n, 1); const rows = (SEA.n === n ? SEA.rows : await db.kvGet('sea:' + n)) || {};
  const top = Object.entries(rows).sort((a, b) => b[1].pts - a[1].pts).slice(0, 3);
  for (let i = 0; i < top.length; i++) { const id = +top[i][0]; await C.withUser(id, u => { const pz = C.scaled(u, D.SEA_PRIZES[i]); C.money(u, pz); u.d.trophies = u.d.trophies || []; u.d.trophies.push({ n, rank: i + 1 });
      if (i === 0) u.d.unlocks.push('t:Champion de la saison ' + n); C.notify(u, { ic: ['🏆', '🥈', '🥉'][i], from: 'Fin de la saison ' + n, body: `Tu finis ${i + 1}${i ? 'e' : 'er'} de la saison ! +${C.eur(pz)} et un trophée`, big: 1, keep: 1 }); }); }
  if (top.length && C.sysChat) C.sysChat(`🏆 Fin de la saison ${n} ! ${top.map((r, i) => (i + 1) + '. ' + r[1].p).join(' · ')}. Nouvelle saison, nouveau passe, tout le monde repart à zéro.`); }
setTimeout(() => seaLoad().catch(e => console.error('sea', e.message)), 3500);
setInterval(() => seaLoad().catch(e => console.error('sea', e.message)), 60000);
setInterval(() => { if (seaDirty) { seaDirty = false; db.kvSet('sea:' + SEA.n, SEA.rows).catch(() => {}); } }, 30000);
function seaMine(u) { const n = seaInfo().n; if (!u.d.sea || u.d.sea.n !== n) u.d.sea = { n, pts: 0, net: 0, claimed: [] }; return u.d.sea; }
const rivalT = new Map();
function seaAdd(u, pts) { if (!SEA.n || !pts) return; const s = seaMine(u); const before = s.pts; s.pts += pts; const r = SEA.rows[u.id] = SEA.rows[u.id] || { p: u.pseudo, pts: 0, av: null }; r.p = u.pseudo; r.av = u.d.av.v2; r.pts = s.pts; seaDirty = true;
  // rivalité : prévenir ceux qu'on vient de dépasser
  Object.entries(SEA.rows).forEach(([id, o]) => { id = +id; if (id === u.id || o.pts < before || o.pts >= s.pts) return; const key = u.id + '>' + id; if (now() - (rivalT.get(key) || 0) < 1800000) return; rivalT.set(key, now());
    C.withUser(id, t => { if (t.d.noRival) return; C.notify(t, { ic: '😤', from: 'Classement de la saison', body: u.pseudo + ' vient de te passer devant. Tu vas laisser faire ?', go: 'season', keep: 1 }); }).catch(() => {}); }); }
C.onXp = (u, n) => { seaAdd(u, Math.round(n)); };
C.api.seaTop = async u => { await seaLoad(); seaMine(u); const rows = Object.entries(SEA.rows).map(([id, r]) => ({ id: +id, pseudo: r.p, av: r.av, pts: r.pts })).sort((a, b) => b.pts - a.pts);
  return { n: SEA.n, start: SEA.info.start, end: SEA.info.end, rows: rows.slice(0, 30), me: rows.findIndex(r => r.id === u.id) + 1, prizes: D.SEA_PRIZES.map(b => C.scaled(u, b)) }; };
C.api.pass7Claim = (u, p) => { const s = seaMine(u), i = +p.i, reached = Math.min(D.PASS7_N, Math.floor(s.pts / D.PASS7_XP)); if (!(i >= 1 && i <= reached) || s.claimed.includes(i)) throw E('Palier pas encore atteint.');
  s.claimed.push(i); const R = D.pass7(i); let txt = R.nm;
  if (R.t === 'cash') { const a = C.scaled(u, R.v); C.money(u, a); txt = '+' + C.eur(a); }
  else if (R.t === 'crate') { u.d.freeCr[R.v] = (u.d.freeCr[R.v] || 0) + 1; }
  else if (R.t === 'boost') { u.d.boosts[R.v] += 3; }
  else if (R.t === 'title') { u.d.unlocks.push('t:' + R.v + ' ' + s.n); }
  else if (R.t === 'nc') { u.d.ncs = [...new Set([...(u.d.ncs || []), R.v])]; u.d.nc = R.v; }
  return { txt }; };
C.api.setNc = (u, p) => { const v = String(p.v || ''); if (v && !(u.d.ncs || []).includes(v)) throw E('Couleur verrouillée.'); u.d.nc = v; return {}; };

/* ---------- Prestige ---------- */
C.api.prestige = u => { const p = u.d.prestige || 0, need = D.prestigeNeed(p); if (C.worth(u) < need) throw E('Il te faut ' + C.eur(need) + ' de patrimoine pour passer en prestige.');
  if (Object.keys(u.s).some(k => u.s[k] && typeof u.s[k] === 'object' && ['mi', 'hl', 'tw', 'ch', 'pe', 'lg', 'bl', 'he', 'di', 'vp', 'ho'].includes(k))) throw E('Termine d\'abord ta partie en cours.');
  const d = u.d; Object.assign(d, { cash: 1000, items: [], biz: [], bizLv: {}, pos: [], debt: 0, gar: [], inv: { dc: 0, dcCost: 0, nft: [], st: [], lv: [] }, lastCollect: Date.now(), nick: null });
  d.prestige = p + 1; d.unlocks.push('t:Prestige ' + d.prestige); C.checkAch(u); C.markDirty(u); C.push(u);
  C.feed(`<b>${C.esc(u.pseudo)}</b> passe en PRESTIGE ${d.prestige} et repart de zéro`); C.sysChat && C.sysChat(`⭐ ${u.pseudo} passe en PRESTIGE ${d.prestige} ! Il abandonne ${C.eur(need)} pour l'honneur (et +${d.prestige * 10} % d'XP pour toujours).`);
  return { prestige: d.prestige }; };

/* ---------- Événements : week-end, Halloween ---------- */
C.xpMult = u => { const dk = C.dkeyParis(); return (D.isWeekend(dk) ? 1.5 : 1); };
C.hello.push(() => { const dk = C.dkeyParis(); return { ev7: D.eventOn(dk), weekend: D.isWeekend(dk), season: seaInfo() }; });
C.api.pumpkinBuy = (u, p) => { const it = D.PUMPKIN_SHOP[+p.i]; if (!it) throw E('Article inconnu.'); if ((u.d.pumpkin || 0) < it.n) throw E('Il te faut ' + it.n + ' citrouilles.'); u.d.pumpkin -= it.n;
  if (it.t === 'crate') u.d.freeCr[it.v] = (u.d.freeCr[it.v] || 0) + 1; else if (it.t === 'title') u.d.unlocks.push('t:' + it.v); else if (it.t === 'nc') { u.d.ncs = [...new Set([...(u.d.ncs || []), it.v])]; u.d.nc = it.v; }
  return { txt: it.nm }; };

/* ---------- Boss de la semaine : Gérard l'huissier ---------- */
let BOSS = { wk: '', hp: D.BOSS7.hp, max: D.BOSS7.hp, dmg: {}, dead: 0 }, bossDirty = false;
async function bossLoad() { const wk = C.weekKey(); if (BOSS.wk !== wk) { const v = await db.kvGet('boss:' + wk); BOSS = v || { wk, hp: D.BOSS7.hp, max: D.BOSS7.hp, dmg: {}, dead: 0 }; } return BOSS; }
setTimeout(() => bossLoad().catch(() => {}), 2500); setInterval(() => { bossLoad().catch(() => {}); if (bossDirty) { bossDirty = false; db.kvSet('boss:' + BOSS.wk, BOSS).catch(() => {}); } }, 20000);
const bossView = () => ({ wk: BOSS.wk, hp: BOSS.hp, max: BOSS.max, dead: BOSS.dead, n: Object.keys(BOSS.dmg).length });
C.hello.push(u => ({ boss: { ...bossView(), mine: (BOSS.dmg[u.id] || {}).d || 0 } }));
let bossEmitT = null; const bossEmit = () => { if (bossEmitT) return; bossEmitT = setTimeout(() => { bossEmitT = null; io() && io().emit('boss', bossView()); }, 3000); };
async function bossKill() { BOSS.dead = now(); bossDirty = true; io() && io().emit('boss', bossView()); C.sysChat && C.sysChat(`🥊 GÉRARD L'HUISSIER EST TOMBÉ ! ${Object.keys(BOSS.dmg).length} joueurs se partagent le butin. Rendez-vous lundi pour le prochain.`);
  for (const [id, r] of Object.entries(BOSS.dmg)) { if (r.d < D.BOSS7.min) continue; await C.withUser(+id, u => { const amt = Math.round(C.scaled(u, D.BOSS7.base) * Math.min(1, r.d / D.BOSS7.full)); C.money(u, amt); u.d.bossKills = (u.d.bossKills || 0) + 1; C.checkAch(u);
      C.notify(u, { ic: '🥊', from: 'Gérard est tombé', body: 'Ta part du butin : +' + C.eur(amt) + ' (' + r.d + ' coups portés)', big: 1, keep: 1 }); }).catch(() => {}); } }
function bossHit(u, stake) { if (BOSS.wk !== C.weekKey() || BOSS.dead || BOSS.hp <= 0) return; const dmg = D.bossDmg(stake); const r = BOSS.dmg[u.id] = BOSS.dmg[u.id] || { p: u.pseudo, d: 0 }; r.d += dmg; BOSS.hp = Math.max(0, BOSS.hp - dmg); bossDirty = true;
  if (BOSS.hp <= 0) bossKill(); else bossEmit(); }
C.api.bossTop = async u => { await bossLoad(); return { ...bossView(), mine: (BOSS.dmg[u.id] || {}).d || 0, rows: Object.entries(BOSS.dmg).map(([id, r]) => ({ id: +id, pseudo: r.p, d: r.d })).sort((a, b) => b.d - a.d).slice(0, 20), reward: C.scaled(u, D.BOSS7.base) }; };

/* ---------- Le crochet commun : chaque partie jouée ---------- */
const _res = C.result;
C.result = (u, game, stake, payout, extra = {}) => { _res(u, game, stake, payout, extra); if (!(stake > 0)) return;
  vipSettle(u); u.d.vw.net += payout - stake;
  if (casinoGame(game)) { u.d.wag = (u.d.wag || 0) + stake; jpRoll(u, stake); bossHit(u, stake);
    const ev = D.eventOn(C.dkeyParis()); if (ev && ev.k === 'halloween' && Math.random() < .04) { u.d.pumpkin = (u.d.pumpkin || 0) + 1; u.sockets.forEach(s => s.emit('pumpkin', { n: u.d.pumpkin })); } } };
C.hello.push(u => { vipSettle(u); seaMine(u); return {}; });
module.exports = {};
