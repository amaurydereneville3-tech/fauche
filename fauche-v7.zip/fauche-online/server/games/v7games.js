// Jeux V7 : Tour de lingots refaite, Bonbons Fous, Pêche Miraculeuse, Coffre-fort en direct.
const C = require('../core');
const db = require('../db');
const { D, rnd, pick, shuffle, E } = C;
function open(u, g) { if (Date.now() < u.d.banUntil) throw E('Tu es interdit de casino encore ' + Math.ceil((u.d.banUntil - Date.now()) / 1000) + ' s.'); if (g && D.GLV[g] && C.LV(u) < D.GLV[g]) throw E('Ce jeu se débloque au niveau ' + D.GLV[g] + '.'); }
const cw = (u, pay, stake) => pay > stake ? pay + C.casinoWin(u, pay - stake) : pay;
const wpick = (list, tw) => { let r = Math.random() * tw; for (const x of list) { if ((r -= x.w) < 0) return x; } return list[list.length - 1]; };

/* ---------- Tour de lingots (V7) ---------- */
const L = D.LG2;
C.api.lgStart = (u, p) => { open(u, 'lingots'); if (u.s.lg) throw E('Termine ta tour de lingots.'); const bet = C.pay(u, p.amt), t = Date.now();
  const traps = shuffle([5, 6, 7, 8, 9, 10, 11]).slice(0, 2).sort((a, b) => a - b);
  u.s.lg = { bet, f: 0, w: L.w0, x: 0, t0: t, ph: Math.random() * 20, inv: false, combo: 0, traps, rows: [] };
  return { t0: t, ph: u.s.lg.ph, inv: false, traps, w: L.w0, now: t }; };
C.api.lgTap = (u, p) => { const g = u.s.lg; if (!g) throw E('Pas de partie en cours.'); const el = Date.now() - g.t0; let ms = Math.floor(+p.ms); if (!(ms >= 0)) ms = el;
  ms = Math.max(el - 500, Math.min(ms, el + 200));
  const x = D.lg2Pos(ms, g.w, g.f, g.ph, g.inv); let nx = x, nw = g.w, perfect = false, grow = false;
  if (g.f > 0) { const a = Math.max(x, g.x), b = Math.min(x + g.w, g.x + g.w); nw = b - a; nx = a; perfect = nw === g.w; }
  if (nw <= 0) { u.s.lg = null; C.result(u, 'lingots', g.bet, 0, { mult: 0 }); return { x, w: g.w, lose: 1, f: g.f }; }
  if (g.f > 0) { if (perfect) { g.combo++; if (g.combo >= L.combo && nw < L.w0) { g.combo = 0; nw++; grow = true; if (nx + nw > L.cols) nx = L.cols - nw; } } else g.combo = 0; }
  g.f++; g.w = nw; g.x = nx; g.rows.push([nx, nw]); g.t0 = g.t0 + ms; g.ph = Math.random() * 20; g.inv = g.traps.includes(g.f);
  if (g.f >= L.floors) { u.d.lgTop = (u.d.lgTop || 0) + 1; C.feed(`<b>${C.esc(u.pseudo)}</b> ouvre le coffre au sommet de la Tour de lingots !`); C.sysChat && C.sysChat(`🧱 ${u.pseudo} a atteint le coffre au sommet de la Tour de lingots (×${L.mult[L.floors]}) !`); return { x: nx, w: nw, f: g.f, perfect, grow, ...C.api.lgOut(u) }; }
  return { x: nx, w: nw, f: g.f, perfect, grow, combo: g.combo, m: L.mult[g.f], t0: g.t0, ph: g.ph, inv: g.inv }; };
C.api.lgOut = u => { const g = u.s.lg; if (!g || g.f < L.min) throw E('Pose au moins ' + L.min + ' étages avant d\'encaisser.'); u.s.lg = null; const m = L.mult[g.f]; let pay = Math.round(g.bet * m); pay = cw(u, pay, g.bet);
  C.money(u, pay); C.result(u, 'lingots', g.bet, pay, { mult: g.f }); C.checkAch(u); return { pay, m, done: 1, f: g.f }; };

/* ---------- Bonbons Fous ---------- */
const BF = D.BF;
function bfRoll(fs) { const list = [...BF.sym, BF.sc].concat(fs ? [BF.bomb] : []); const tw = list.reduce((a, x) => a + x.w, 0); const s = wpick(list, tw); return s.k === 'bomb' ? 'bomb:' + pick(BF.bomb.v) : s.k; }
function bfSpin(bet, fs) { let g = Array.from({ length: BF.cols }, () => Array.from({ length: BF.rows }, () => bfRoll(fs))); const steps = []; let tot = 0;
  for (let k = 0; k < 40; k++) { const cnt = {}; g.forEach(col => col.forEach(s => { cnt[s] = (cnt[s] || 0) + 1; }));
    let win = 0; const wins = []; BF.sym.forEach(S => { const n = cnt[S.k] || 0; if (n >= 8) { const v = bet * S.p[n >= 12 ? 2 : n >= 10 ? 1 : 0] * BF.adj; win += v; wins.push(S.k); } });
    const step = { grid: g.map(c => [...c]), hit: wins, win: Math.round(win) }; steps.push(step); if (!win) break; tot += win;
    g = g.map(col => { const keep = col.filter(s => !wins.includes(s)); const n = BF.rows - keep.length; return [...Array.from({ length: n }, () => bfRoll(fs)), ...keep]; }); }
  const fin = steps[steps.length - 1].grid, sc = fin.flat().filter(s => s === 'lolly').length, bombs = fs && tot > 0 ? fin.flat().filter(s => s.startsWith('bomb:')).map(s => +s.slice(5)) : [];
  const mult = bombs.length ? bombs.reduce((a, b) => a + b, 0) : 1; return { steps, base: Math.round(tot), mult, tot: Math.round(tot * mult), sc, bombs }; }
function bfPlay(bet, buy) { const spins = []; let total = 0, fsLeft = 0, fsTot = 0;
  if (!buy) { const s = bfSpin(bet, false); spins.push(s); total += s.tot; if (s.sc >= 4) { total += bet * (BF.scPay[Math.min(6, s.sc)] || 0); s.scWin = bet * (BF.scPay[Math.min(6, s.sc)] || 0); fsLeft = BF.fs; } }
  else fsLeft = BF.fs;
  while (fsLeft > 0 && fsTot < 60) { fsLeft--; fsTot++; const s = bfSpin(bet, true); s.free = 1; spins.push(s); total += s.tot; if (s.sc >= 3) { fsLeft += 5; s.retrig = 5; } }
  return { spins, total: Math.round(total), fs: fsTot }; }
C.bfPlay = bfPlay;
C.api.bfSpin = (u, p) => { open(u, 'bonbons'); const buy = !!p.buy; const bet = C.int(p.amt); C.pay(u, buy ? bet * BF.buy : bet); const r = bfPlay(bet, buy); const stake = buy ? bet * BF.buy : bet;
  const pay = cw(u, r.total, stake); if (pay) C.money(u, pay); C.result(u, 'bonbons', stake, pay, { mult: Math.round(pay / bet) });
  if (pay >= bet * 200 && C.sysChat) C.sysChat(`🍭 ${u.pseudo} vient de gagner ${C.eur(pay)} aux Bonbons Fous (×${Math.round(pay / bet)}) !`); return { ...r, total: pay, bet, stake }; };

/* ---------- Pêche Miraculeuse ---------- */
const PM = D.PM;
function pmRoll(fs) { const list = [...PM.sym, PM.fish, PM.sc, { ...PM.wild, w: fs ? PM.fsWild : PM.wild.w }]; const tw = list.reduce((a, x) => a + x.w, 0); const s = wpick(list, tw); return s.k === 'fish' ? 'fish:' + pick(PM.fish.v) : s.k; }
function pmSpin(bet, fs, cm) { const g = Array.from({ length: 5 }, () => Array.from({ length: 3 }, () => pmRoll(fs))); const lb = bet / 10; let win = 0; const lines = [];
  PM.lines.forEach((Ln, li) => { const cells = Ln.map((r, c) => g[c][r]); let base = null, n = 0; for (const s of cells) { if (s === 'man') { if (fs) break; n++; continue; } if (s.startsWith('fish') || s === 'hook') break; if (base === null) { base = s; n++; continue; } if (s === base) n++; else break; }
    if (base === null || n < 3) return; const S = PM.sym.find(x => x.k === base); if (!S) return; const v = lb * S.p[n - 3] * PM.adj; win += v; lines.push([li, n, Math.round(v)]); });
  const sc = g.flat().filter(s => s === 'hook').length, men = g.flat().filter(s => s === 'man').length, fishSum = g.flat().filter(s => s.startsWith('fish:')).reduce((a, s) => a + +s.slice(5), 0);
  let col = 0; if (fs && men && fishSum) col = Math.round(men * fishSum * bet * cm * PM.adj);
  return { grid: g, lines, win: Math.round(win), sc, men, fishSum, col, tot: Math.round(win) + col }; }
function pmPlay(bet, force) { const spins = []; let total = 0; const s0 = pmSpin(bet, false, 1); if (force) { s0.sc = 3; s0.tot = 0; } spins.push(s0); total += s0.tot; let fsLeft = 0, fsTot = 0, menTot = 0, cm = 1;
  if (s0.sc >= 3) { const sp = { 3: 2, 4: 5, 5: 20 }[Math.min(5, s0.sc)] * bet; s0.scWin = sp; total += sp; fsLeft = PM.fs; }
  while (fsLeft > 0 && fsTot < 50) { fsLeft--; fsTot++; const s = pmSpin(bet, true, cm); s.free = 1; s.cm = cm; spins.push(s); total += s.tot; const before = Math.floor(menTot / 4); menTot += s.men;
    const after = Math.floor(menTot / 4); if (after > before && cm < 10) { const lv = Math.min(3, after); cm = [1, 2, 3, 10][lv]; fsLeft += 10; s.retrig = 10; s.newCm = cm; } }
  return { spins, total: Math.round(total), fs: fsTot }; }
C.pmPlay = pmPlay;
C.api.pmSpin = (u, p) => { open(u, 'peche'); const bet = C.pay(u, p.amt); const r = pmPlay(bet); const pay = cw(u, r.total, bet); if (pay) C.money(u, pay);
  C.result(u, 'peche', bet, pay, { mult: Math.round(pay / bet) }); if (pay >= bet * 150 && C.sysChat) C.sysChat(`🎣 ${u.pseudo} remonte ${C.eur(pay)} à la Pêche Miraculeuse (×${Math.round(pay / bet)}) !`); return { ...r, total: pay, bet }; };

/* ---------- Coffre-fort en direct ---------- */
const CF = {}; let cfT = null;
const newCode = () => shuffle([...'0123456789']).slice(0, D.CF_LEN).join('');
function cfNew(k, pot) { CF[k] = { k, code: newCode(), pot: pot || 0, log: [], round: ((CF[k] && CF[k].round) || 0) + 1, win: null, openAt: Date.now() }; }
D.CF.forEach(c => cfNew(c.k));
db.kvGet('cf7').then(v => { if (v) D.CF.forEach(c => { if (v[c.k]) CF[c.k] = { ...v[c.k], log: (v[c.k].log || []).slice(0, 40) }; }); }).catch(() => {});
const cfSave = () => db.kvSet('cf7', CF).catch(() => {});
const cfView = () => Object.fromEntries(D.CF.map(c => { const s = CF[c.k]; return [c.k, { k: c.k, pot: s.pot, round: s.round, log: s.log.slice(0, 30), win: s.win, openAt: s.openAt, code: s.win ? s.code : null }]; }));
function cfEmit() { if (cfT) return; cfT = setTimeout(() => { cfT = null; C.io && C.io.to('cf').emit('cf', cfView()); }, 120); }
C.hello.push(() => ({ cfPots: Object.fromEntries(D.CF.map(c => [c.k, CF[c.k].pot])) }));
C.api.cfJoin = (u, p, s) => { s && s.join('cf'); return { cf: cfView(), now: Date.now() }; };
C.api.cfLeave = (u, p, s) => { s && s.leave('cf'); return {}; };
C.api.cfGuess = (u, p) => { open(u, 'cf'); const T = D.CF.find(c => c.k === p.k); if (!T) throw E('Coffre inconnu.'); const s = CF[T.k]; if (s.win || Date.now() < s.openAt) throw E('Un nouveau coffre arrive, patience…');
  const g = String(p.g || ''); if (!new RegExp('^\\d{' + D.CF_LEN + '}$').test(g) || new Set(g).size !== D.CF_LEN) throw E('Tape ' + D.CF_LEN + ' chiffres tous différents.');
  u.s.cfAt = u.s.cfAt || {}; if (Date.now() - (u.s.cfAt[T.k] || 0) < D.CF_CD) throw E('Le coffre chauffe… attends quelques secondes.'); u.s.cfAt[T.k] = Date.now();
  C.pay(u, T.fee); s.pot += Math.round(T.fee * (1 - D.CF_CUT)); const sc = D.cfScore(s.code, g); s.log.unshift({ p: u.pseudo, uid: u.id, g, b: sc.b, m: sc.m, t: Date.now() }); s.log.length = Math.min(s.log.length, 40);
  if (sc.b === D.CF_LEN) { const pot = s.pot; s.win = { p: u.pseudo, uid: u.id, pot, t: Date.now() }; C.money(u, pot); u.d.cfWins = (u.d.cfWins || 0) + 1; C.result(u, 'cf', T.fee, pot); C.checkAch(u);
    C.sysChat && C.sysChat(`🔐 ${u.pseudo} a cracké le ${T.nm} : ${C.eur(pot)} dans la poche !`); C.feed(`<b>${C.esc(u.pseudo)}</b> crack le ${T.nm} (${C.eur(pot)})`);
    setTimeout(() => { cfNew(T.k, 0); CF[T.k].openAt = Date.now() + 3000; cfEmit(); cfSave(); }, 9000); }
  else C.result(u, 'cf', T.fee, 0);
  cfEmit(); cfSave(); return { ...sc, pot: s.pot }; };
module.exports = { CF };
